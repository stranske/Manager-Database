"""Manager API endpoint and supporting models."""

from __future__ import annotations

import csv
import io
import json
import logging
import math
import os
import re
import sqlite3
from datetime import UTC, datetime
from functools import wraps
from typing import Annotated, Any, cast

from fastapi import APIRouter, Body, HTTPException, Path, Query, Request, Response
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from adapters.base import connect_db
from adapters.base import resolve_manager_id_column as shared_manager_id_column
from api.cache import cache_query, invalidate_cache_prefix
from api.models import (
    BulkImportFailure,
    BulkImportItemError,
    BulkImportResponse,
    BulkImportSuccess,
    ManagerListResponse,
    ManagerResponse,
    ManagerStatsResponse,
    UniverseImportResponse,
)
from etl.manager_similarity_flow import ensure_manager_similarity_table
from services.manager_deletion import (
    AmbiguousManagerObjectsError,
    ManagerObjectDeletionError,
    delete_manager_data,
)
from utils.identifiers import normalize_cik

router = APIRouter()
logger = logging.getLogger(__name__)

try:  # pragma: no cover - optional dependency
    import psycopg as psycopg
except ImportError:  # pragma: no cover - psycopg not installed for SQLite-only tests
    psycopg = None  # type: ignore[assignment]

DB_ERROR_TYPES: tuple[type[BaseException], ...] = (sqlite3.Error,)
if psycopg is not None:
    DB_ERROR_TYPES = DB_ERROR_TYPES + (psycopg.Error,)

# Keep validation rules centralized so API docs/tests stay in sync with behavior.
REQUIRED_FIELD_ERRORS = {
    "name": "Name is required.",
}
DEFAULT_BULK_IMPORT_MAX_BYTES = 2_000_000
CIK_PATTERN = re.compile(r"^\d{10}$")
SQLITE_TABLE_INFO_SQL = "SELECT name FROM pragma_table_info(?)"
# Python str.strip() recognizes these Unicode whitespace characters. SQL's
# default TRIM only removes spaces, so database lookups need the explicit set.
CIK_WHITESPACE_CODEPOINTS = (
    9,
    10,
    11,
    12,
    13,
    28,
    29,
    30,
    31,
    32,
    133,
    160,
    5760,
    8192,
    8193,
    8194,
    8195,
    8196,
    8197,
    8198,
    8199,
    8200,
    8201,
    8202,
    8232,
    8233,
    8239,
    8287,
    12288,
)
BULK_CIK_LOOKUP_CHUNK_SIZE = 900


class ManagerCreate(BaseModel):
    """Payload for creating manager records."""

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "name": "Elliott Investment Management L.P.",
                    "cik": "0001791786",
                    "lei": "549300U3N12T57QLOU60",
                    "aliases": ["Elliott Management"],
                    "jurisdictions": ["us"],
                    "tags": ["activist"],
                    "registry_ids": {"fca_frn": "122927"},
                }
            ]
        }
    )
    name: str = Field(..., description="Legal name of the investment manager")
    cik: str | None = Field(None, description="SEC Central Index Key")
    lei: str | None = Field(None, description="Legal Entity Identifier")
    aliases: list[str] = Field(default_factory=list, description="Alternative names")
    jurisdictions: list[str] = Field(
        default_factory=list, description="Filing jurisdictions (us, uk, ca)"
    )
    tags: list[str] = Field(default_factory=list, description="Classification tags")
    registry_ids: dict[str, str] = Field(default_factory=dict, description="External registry IDs")


class ManagerUpdate(BaseModel):
    """Payload for partially updating manager records."""

    name: str | None = Field(None, description="Legal name of the investment manager")
    cik: str | None = Field(None, description="SEC Central Index Key")
    lei: str | None = Field(None, description="Legal Entity Identifier")
    aliases: list[str] | None = Field(None, description="Alternative names")
    jurisdictions: list[str] | None = Field(None, description="Filing jurisdictions (us, uk, ca)")
    tags: list[str] | None = Field(None, description="Classification tags")
    registry_ids: dict[str, str] | None = Field(None, description="External registry IDs")


class ManagerTagsPatch(BaseModel):
    """Payload for appending/removing manager tags."""

    add: list[str] = Field(default_factory=list, description="Tags to append if missing")
    remove: list[str] = Field(default_factory=list, description="Tags to remove if present")


class NotFoundResponse(BaseModel):
    """Response payload for missing resources."""

    detail: str = Field(..., description="Error detail message")


class ErrorDetail(BaseModel):
    """Single validation error detail."""

    field: str = Field(..., description="Field that failed validation")
    message: str = Field(..., description="Validation error message")


class ErrorResponse(BaseModel):
    """Response payload for validation errors."""

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "errors": [{"field": "name", "message": "Name is required."}],
                    "error": [{"field": "name", "message": "Name is required."}],
                }
            ]
        }
    )
    errors: list[ErrorDetail] = Field(..., description="List of validation errors")
    error: list[ErrorDetail] | None = Field(None, description="Alias for validation errors")


def _ensure_manager_table(conn) -> None:
    """Ensure the managers table is available."""
    if isinstance(conn, sqlite3.Connection):
        conn.execute("""CREATE TABLE IF NOT EXISTS managers (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                cik TEXT,
                lei TEXT,
                aliases TEXT NOT NULL DEFAULT '[]',
                jurisdictions TEXT NOT NULL DEFAULT '[]',
                tags TEXT NOT NULL DEFAULT '[]',
                registry_ids TEXT NOT NULL DEFAULT '{}',
                quality_flags TEXT NOT NULL DEFAULT '[]',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )""")
        columns = {
            str(row[0]) for row in conn.execute(SQLITE_TABLE_INFO_SQL, ("managers",)).fetchall()
        }
        if "quality_flags" not in columns:
            conn.execute("ALTER TABLE managers ADD COLUMN quality_flags TEXT NOT NULL DEFAULT '[]'")
        return
    conn.execute("SELECT 1 FROM managers LIMIT 1")
    conn.execute(
        "ALTER TABLE managers ADD COLUMN IF NOT EXISTS quality_flags jsonb DEFAULT '[]'::jsonb"
    )


def _manager_id_column(conn) -> str:
    """Return the manager primary-key column for the active database backend."""
    return shared_manager_id_column(conn)


def _json_array(raw: object) -> list[str]:
    if raw is None:
        return []
    if isinstance(raw, list):
        return [str(item) for item in raw]
    if isinstance(raw, str):
        text = raw.strip()
        if not text:
            return []
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError:
            if ";" in text:
                return [part.strip() for part in text.split(";") if part.strip()]
            if "," in text:
                return [part.strip() for part in text.split(",") if part.strip()]
            return [text]
        if isinstance(parsed, list):
            return [str(item) for item in parsed]
    return []


def _json_dict(raw: object) -> dict[str, str]:
    if raw is None:
        return {}
    if isinstance(raw, dict):
        return {str(key): str(value) for key, value in raw.items()}
    if isinstance(raw, str):
        text = raw.strip()
        if not text:
            return {}
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError:
            return {}
        if isinstance(parsed, dict):
            return {str(key): str(value) for key, value in parsed.items()}
    return {}


def _json_object_list(raw: object) -> list[dict[str, object]]:
    if raw is None:
        return []
    if isinstance(raw, list):
        return [item for item in raw if isinstance(item, dict)]
    if isinstance(raw, str):
        text = raw.strip()
        if not text:
            return []
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError:
            return []
        if isinstance(parsed, list):
            return [item for item in parsed if isinstance(item, dict)]
    return []


def _to_manager_response(row: tuple[object, ...]) -> ManagerResponse:
    manager_id_raw = row[0]
    if not isinstance(manager_id_raw, (int, str)):
        manager_id_raw = 0
    quality_flags_raw = row[8] if len(row) > 10 else []
    created_at_raw = row[9] if len(row) > 10 else row[8]
    updated_at_raw = row[10] if len(row) > 10 else row[9]
    return ManagerResponse(
        manager_id=int(cast(int | str, manager_id_raw)),
        name=str(row[1]),
        cik=str(row[2]) if row[2] is not None else None,
        lei=str(row[3]) if row[3] is not None else None,
        aliases=_json_array(row[4]),
        jurisdictions=_json_array(row[5]),
        tags=_json_array(row[6]),
        registry_ids=_json_dict(row[7]),
        quality_flags=_json_object_list(quality_flags_raw),
        created_at=str(created_at_raw) if created_at_raw is not None else None,
        updated_at=str(updated_at_raw) if updated_at_raw is not None else None,
    )


class LegacyDuplicateCikError(Exception):
    """Existing CIK owners must be reconciled before uniqueness can be enabled."""


def _check_legacy_cik_duplicates(conn: Any) -> None:
    """Require explicit cleanup without rewriting or deleting existing managers."""
    # A raw unique index cannot establish uniqueness after CIK whitespace normalization.
    # Always check the same expression used by request lookup, including legacy indexed tables.
    normalized_cik = _cik_lookup_expression(conn)
    # Whitespace-only identifiers are absent, just like NULL CIKs in new payloads.
    duplicate = conn.execute(
        f"SELECT 1 FROM managers WHERE cik IS NOT NULL AND {normalized_cik} <> '' "
        f"GROUP BY {normalized_cik} HAVING COUNT(*) > 1 LIMIT 1"
    ).fetchone()
    if duplicate:
        raise LegacyDuplicateCikError


def _ensure_universe_schema(conn: Any, *, check_legacy_ciks: bool = False) -> None:
    """Ensure managers table has the columns/index needed for universe imports."""
    _ensure_manager_table(conn)
    if isinstance(conn, sqlite3.Connection):
        columns = {
            str(row[0]) for row in conn.execute(SQLITE_TABLE_INFO_SQL, ("managers",)).fetchall()
        }
        if "cik" not in columns:
            conn.execute("ALTER TABLE managers ADD COLUMN cik TEXT")
        if "jurisdiction" not in columns:
            conn.execute("ALTER TABLE managers ADD COLUMN jurisdiction TEXT")
        if "jurisdictions" not in columns:
            conn.execute("ALTER TABLE managers ADD COLUMN jurisdictions TEXT NOT NULL DEFAULT '[]'")
        if "created_at" not in columns:
            conn.execute("ALTER TABLE managers ADD COLUMN created_at TIMESTAMP")
            conn.execute(
                "UPDATE managers SET created_at = CURRENT_TIMESTAMP WHERE created_at IS NULL"
            )
        if "updated_at" not in columns:
            conn.execute("ALTER TABLE managers ADD COLUMN updated_at TIMESTAMP")
            conn.execute(
                "UPDATE managers SET updated_at = CURRENT_TIMESTAMP WHERE updated_at IS NULL"
            )
        if "quality_flags" not in columns:
            conn.execute("ALTER TABLE managers ADD COLUMN quality_flags TEXT NOT NULL DEFAULT '[]'")
        if check_legacy_ciks:
            _check_legacy_cik_duplicates(conn)
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_managers_cik_unique ON managers(cik)")
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_managers_trimmed_cik ON managers "
            f"({_cik_lookup_expression(conn)})"
        )
        conn.commit()
        return

    conn.execute("ALTER TABLE managers ADD COLUMN IF NOT EXISTS cik text")
    conn.execute("ALTER TABLE managers ADD COLUMN IF NOT EXISTS jurisdiction text")
    conn.execute("ALTER TABLE managers ADD COLUMN IF NOT EXISTS jurisdictions text[] DEFAULT '{}'")
    conn.execute(
        "ALTER TABLE managers ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now()"
    )
    conn.execute(
        "ALTER TABLE managers ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now()"
    )
    conn.execute(
        "ALTER TABLE managers ADD COLUMN IF NOT EXISTS quality_flags jsonb DEFAULT '[]'::jsonb"
    )
    if check_legacy_ciks:
        _check_legacy_cik_duplicates(conn)
    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_managers_cik_unique ON managers(cik)")
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_managers_trimmed_cik ON managers "
        f"({_cik_lookup_expression(conn)})"
    )


def _cik_lookup_expression(conn: Any) -> str:
    """Return the indexed SQL expression matching payload CIK whitespace trimming."""
    if isinstance(conn, sqlite3.Connection):
        codes = ", ".join(str(code) for code in CIK_WHITESPACE_CODEPOINTS)
        return f"TRIM(cik, char({codes}))"
    characters = " || ".join(f"chr({code})" for code in CIK_WHITESPACE_CODEPOINTS)
    return f"BTRIM(cik, {characters})"


def _manager_exists_for_cik(conn: Any, cik: str) -> bool:
    placeholder = "?" if isinstance(conn, sqlite3.Connection) else "%s"
    row = conn.execute(
        f"SELECT 1 FROM managers WHERE {_cik_lookup_expression(conn)} = {placeholder} LIMIT 1",
        (cik.strip(),),
    ).fetchone()
    return bool(row)


def _is_cik_unique_violation(exc: BaseException) -> bool:
    """Recognize CIK conflicts without swallowing unrelated database failures."""
    if isinstance(exc, sqlite3.IntegrityError):
        return "UNIQUE constraint failed: managers.cik" in str(exc)
    return getattr(exc, "sqlstate", None) == "23505" and (
        getattr(getattr(exc, "diag", None), "constraint_name", None) == "idx_managers_cik_unique"
    )


def _upsert_universe_record(conn: Any, name: str, cik: str, jurisdiction: str) -> None:
    jurisdictions = [jurisdiction]
    if isinstance(conn, sqlite3.Connection):
        conn.execute(
            """
            INSERT INTO managers(name, cik, jurisdiction, jurisdictions, updated_at)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(cik)
            DO UPDATE SET
                name = excluded.name,
                jurisdiction = excluded.jurisdiction,
                jurisdictions = excluded.jurisdictions,
                updated_at = CURRENT_TIMESTAMP
            """,
            (name, cik, jurisdiction, json.dumps(jurisdictions)),
        )
        return
    conn.execute(
        """
        INSERT INTO managers(name, cik, jurisdiction, jurisdictions, updated_at)
        VALUES (%s, %s, %s, %s, now())
        ON CONFLICT(cik)
        DO UPDATE SET
            name = EXCLUDED.name,
            jurisdiction = EXCLUDED.jurisdiction,
            jurisdictions = EXCLUDED.jurisdictions,
            updated_at = now()
        """,
        (name, cik, jurisdiction, jurisdictions),
    )


def _insert_manager(conn, payload: ManagerCreate, *, commit: bool = True) -> int:
    """Insert a manager record and return the generated id."""
    if isinstance(conn, sqlite3.Connection):
        cursor = conn.execute(
            (
                "INSERT INTO managers(name, cik, lei, aliases, jurisdictions, tags, registry_ids) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)"
            ),
            (
                payload.name,
                payload.cik,
                payload.lei,
                json.dumps(payload.aliases),
                json.dumps(payload.jurisdictions),
                json.dumps(payload.tags),
                json.dumps(payload.registry_ids),
            ),
        )
        if commit:
            conn.commit()
        lastrowid = cursor.lastrowid
        return int(lastrowid) if lastrowid is not None else 0
    id_column = _manager_id_column(conn)
    cursor = conn.execute(
        (
            "INSERT INTO managers(name, cik, lei, aliases, jurisdictions, tags, registry_ids) "
            f"VALUES (%s, %s, %s, %s, %s, %s, %s::jsonb) RETURNING {id_column}"
        ),
        (
            payload.name,
            payload.cik,
            payload.lei,
            payload.aliases,
            payload.jurisdictions,
            payload.tags,
            json.dumps(payload.registry_ids),
        ),
    )
    row = cursor.fetchone()
    if not row or row[0] is None:
        return 0
    return int(row[0])


def _update_manager(conn, manager_id: int, payload: ManagerUpdate) -> bool:
    """Update a manager record and return whether a row changed."""
    fields = payload.model_dump(exclude_unset=True)
    if not fields:
        return False

    set_clauses: list[str] = []
    params: list[object] = []
    placeholder = "?" if isinstance(conn, sqlite3.Connection) else "%s"
    id_column = _manager_id_column(conn)
    current_row = conn.execute(
        f"SELECT cik, lei, registry_ids, quality_flags FROM managers WHERE {id_column} = {placeholder}",
        (manager_id,),
    ).fetchone()
    if current_row is None:
        return False
    quality_flags = _json_object_list(current_row[3] if len(current_row) > 3 else [])
    conflict_flags = _manager_conflict_flags(
        current_cik=current_row[0] if len(current_row) > 0 else None,
        current_lei=current_row[1] if len(current_row) > 1 else None,
        current_registry_ids=_json_dict(current_row[2] if len(current_row) > 2 else {}),
        updates=fields,
    )

    for field, value in fields.items():
        if field in {"aliases", "jurisdictions", "tags"}:
            if isinstance(conn, sqlite3.Connection):
                set_clauses.append(f"{field} = {placeholder}")
                params.append(json.dumps(value))
            else:
                set_clauses.append(f"{field} = {placeholder}")
                params.append(value)
            continue
        if field == "registry_ids":
            if isinstance(conn, sqlite3.Connection):
                set_clauses.append(f"{field} = {placeholder}")
                params.append(json.dumps(value))
            else:
                set_clauses.append(f"{field} = {placeholder}::jsonb")
                params.append(json.dumps(value))
            continue
        set_clauses.append(f"{field} = {placeholder}")
        params.append(value)

    if conflict_flags:
        quality_flags.extend(conflict_flags)
        if isinstance(conn, sqlite3.Connection):
            set_clauses.append(f"quality_flags = {placeholder}")
        else:
            set_clauses.append(f"quality_flags = {placeholder}::jsonb")
        params.append(json.dumps(quality_flags))

    set_clauses.append("updated_at = CURRENT_TIMESTAMP")
    params.append(manager_id)

    cursor = conn.execute(
        f"UPDATE managers SET {', '.join(set_clauses)} WHERE {id_column} = {placeholder}",
        params,
    )
    if isinstance(conn, sqlite3.Connection):
        conn.commit()
    return cursor.rowcount > 0


def _manager_conflict_flags(
    *,
    current_cik: object,
    current_lei: object,
    current_registry_ids: dict[str, str],
    updates: dict[str, object],
) -> list[dict[str, object]]:
    observed_at = datetime.now(UTC).isoformat()
    flags: list[dict[str, object]] = []

    def _identifier_conflict_flag(field: str, old_value: str, new_value: str) -> dict[str, object]:
        return {
            "type": "identifier_conflict",
            "field": field,
            "old": old_value,
            "new": new_value,
            "previous_value": old_value,
            "current_value": new_value,
            "observed_at": observed_at,
        }

    for field, current in (("cik", current_cik), ("lei", current_lei)):
        if field not in updates:
            continue
        new_value = updates[field]
        old_text = "" if current is None else str(current).strip()
        new_text = "" if new_value is None else str(new_value).strip()
        if old_text and new_text and old_text != new_text:
            flags.append(_identifier_conflict_flag(field, old_text, new_text))

    registry_update = updates.get("registry_ids")
    if isinstance(registry_update, dict):
        for key, raw_new in registry_update.items():
            registry_key = str(key)
            old_value = current_registry_ids.get(registry_key, "")
            new_value = "" if raw_new is None else str(raw_new).strip()
            if old_value and new_value and old_value != new_value:
                flags.append(
                    _identifier_conflict_flag(
                        f"registry_ids.{registry_key}",
                        old_value,
                        new_value,
                    )
                )
    return flags


def _escape_like(value: str) -> str:
    """Escape user-provided text for a literal SQL LIKE pattern."""
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def _manager_filter_clauses(
    conn,
    jurisdiction: str | None,
    tag: str | None,
    search: str | None,
    name: str | None,
) -> tuple[list[str], list[object]]:
    """Build dialect-portable manager-list predicates and parameters."""
    placeholder = "?" if isinstance(conn, sqlite3.Connection) else "%s"
    params: list[object] = []
    clauses: list[str] = []
    if jurisdiction:
        if isinstance(conn, sqlite3.Connection):
            clauses.append("EXISTS (SELECT 1 FROM json_each(jurisdictions) WHERE value = ?)")
        else:
            clauses.append("%s = ANY(jurisdictions)")
        params.append(jurisdiction)
    if tag:
        if isinstance(conn, sqlite3.Connection):
            clauses.append("EXISTS (SELECT 1 FROM json_each(tags) WHERE value = ?)")
        else:
            clauses.append("%s = ANY(tags)")
        params.append(tag)
    if search:
        pattern = f"%{_escape_like(search.lower())}%"
        if isinstance(conn, sqlite3.Connection):
            clauses.append(
                "(LOWER(name) LIKE ? ESCAPE '\\' OR EXISTS "
                "(SELECT 1 FROM json_each(aliases) WHERE LOWER(value) LIKE ? ESCAPE '\\'))"
            )
        else:
            clauses.append(
                "(LOWER(name) LIKE %s ESCAPE '\\' OR EXISTS "
                "(SELECT 1 FROM unnest(COALESCE(aliases, ARRAY[]::text[])) AS alias(value) "
                "WHERE LOWER(alias.value) LIKE %s ESCAPE '\\'))"
            )
        params.extend([pattern, pattern])
    if name:
        clauses.append(f"LOWER(name) LIKE {placeholder} ESCAPE '\\'")
        params.append(f"{_escape_like(name.lower())}%")
    return clauses, params


@cache_query("managers.count", skip_args=1)
def _count_managers(
    conn,
    db_identity: str,
    jurisdiction: str | None,
    tag: str | None,
    search: str | None,
    name: str | None,
) -> int:
    """Return the total number of managers with optional filters."""
    clauses, params = _manager_filter_clauses(conn, jurisdiction, tag, search, name)
    where_clause = f" WHERE {' AND '.join(clauses)}" if clauses else ""
    cursor = conn.execute(f"SELECT COUNT(*) FROM managers{where_clause}", params)
    row = cursor.fetchone()
    if not row or row[0] is None:
        return 0
    return int(row[0])


@cache_query("managers.list", skip_args=1)
def _fetch_managers(
    conn,
    db_identity: str,
    limit: int,
    offset: int,
    jurisdiction: str | None,
    tag: str | None,
    search: str | None,
    name: str | None,
) -> list[tuple[object, ...]]:
    """Return managers ordered by id with pagination applied."""
    placeholder = "?" if isinstance(conn, sqlite3.Connection) else "%s"
    clauses, params = _manager_filter_clauses(conn, jurisdiction, tag, search, name)
    where_clause = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    params.extend([limit, offset])
    id_column = _manager_id_column(conn)
    cursor = conn.execute(
        f"SELECT {id_column}, name, cik, lei, aliases, jurisdictions, tags, registry_ids, quality_flags, created_at, updated_at "
        f"FROM managers {where_clause} "
        f"ORDER BY {id_column} LIMIT {placeholder} OFFSET {placeholder}",
        params,
    )
    return cursor.fetchall()


@cache_query("managers.item", skip_args=1)
def _fetch_manager(conn, db_identity: str, manager_id: int) -> tuple[object, ...] | None:
    """Return a single manager row by id."""
    placeholder = "?" if isinstance(conn, sqlite3.Connection) else "%s"
    id_column = _manager_id_column(conn)
    cursor = conn.execute(
        (
            f"SELECT {id_column}, name, cik, lei, aliases, jurisdictions, tags, registry_ids, quality_flags, created_at, updated_at "
            f"FROM managers WHERE {id_column} = {placeholder}"
        ),
        (manager_id,),
    )
    return cursor.fetchone()


def _validate_manager_payload(payload: ManagerCreate) -> list[dict[str, str]]:
    """Apply required field checks."""
    errors: list[dict[str, str]] = []
    if not payload.name.strip():
        errors.append({"field": "name", "message": REQUIRED_FIELD_ERRORS["name"]})
    if (
        payload.cik is not None
        and payload.cik.strip()
        and not CIK_PATTERN.match(payload.cik.strip())
    ):
        errors.append({"field": "cik", "message": "CIK must be a 10-digit zero-padded string."})
    return errors


def _validate_manager_update_payload(payload: ManagerUpdate) -> list[dict[str, str]]:
    """Apply validation checks for partial updates."""
    errors: list[dict[str, str]] = []
    provided_fields = payload.model_dump(exclude_unset=True)
    if not provided_fields:
        errors.append({"field": "body", "message": "At least one field must be provided."})
        return errors
    if payload.name is not None and not payload.name.strip():
        errors.append({"field": "name", "message": REQUIRED_FIELD_ERRORS["name"]})
    if (
        payload.cik is not None
        and payload.cik.strip()
        and not CIK_PATTERN.match(payload.cik.strip())
    ):
        errors.append({"field": "cik", "message": "CIK must be a 10-digit zero-padded string."})
    return errors


def _normalize_tags(values: list[str]) -> list[str]:
    """Trim, dedupe, and drop empty tag values while preserving order."""
    normalized: list[str] = []
    seen: set[str] = set()
    for value in values:
        tag = value.strip()
        if not tag or tag in seen:
            continue
        seen.add(tag)
        normalized.append(tag)
    return normalized


def _merge_tags(existing: list[str], add: list[str], remove: list[str]) -> list[str]:
    """Merge add/remove tag operations onto an existing tag list."""
    tags = _normalize_tags(existing)
    for tag in add:
        if tag not in tags:
            tags.append(tag)
    if not remove:
        return tags
    remove_set = set(remove)
    return [tag for tag in tags if tag not in remove_set]


def _fetch_manager_stats_rows(conn: Any) -> list[tuple[Any, ...]]:
    """Fetch columns needed for manager summary stats with schema fallback."""
    try:
        cursor = conn.execute("SELECT cik, lei, jurisdictions, tags, jurisdiction FROM managers")
        return cursor.fetchall()
    except DB_ERROR_TYPES as exc:
        message = str(exc).lower()
        missing_jurisdiction = (
            "no such column: jurisdiction" in message
            or 'column "jurisdiction" does not exist' in message
        )
        if not missing_jurisdiction:
            raise
        cursor = conn.execute("SELECT cik, lei, jurisdictions, tags FROM managers")
        rows = cursor.fetchall()
        return [(row[0], row[1], row[2], row[3], None) for row in rows]


def _build_manager_stats(rows: list[tuple[Any, ...]]) -> ManagerStatsResponse:
    """Aggregate manager universe stats from normalized DB rows."""
    by_jurisdiction: dict[str, int] = {}
    by_tag: dict[str, int] = {}
    with_cik = 0
    with_lei = 0

    for cik, lei, jurisdictions_raw, tags_raw, jurisdiction_raw in rows:
        cik_value = str(cik).strip() if cik is not None else ""
        if cik_value:
            with_cik += 1

        lei_value = str(lei).strip() if lei is not None else ""
        if lei_value:
            with_lei += 1

        jurisdiction_values = _normalize_tags(_json_array(jurisdictions_raw))
        if not jurisdiction_values and jurisdiction_raw is not None:
            fallback_value = str(jurisdiction_raw).strip()
            if fallback_value:
                jurisdiction_values = [fallback_value]
        jurisdiction_values = _normalize_tags([value.lower() for value in jurisdiction_values])
        for jurisdiction in jurisdiction_values:
            by_jurisdiction[jurisdiction] = by_jurisdiction.get(jurisdiction, 0) + 1

        tag_values = _normalize_tags([value.lower() for value in _json_array(tags_raw)])
        for tag in tag_values:
            by_tag[tag] = by_tag.get(tag, 0) + 1

    return ManagerStatsResponse(
        total_managers=len(rows),
        by_jurisdiction=dict(sorted(by_jurisdiction.items())),
        by_tag=dict(sorted(by_tag.items())),
        with_cik=with_cik,
        with_lei=with_lei,
    )


def _require_valid_manager(handler):
    """Decorator to guard manager writes with validation."""

    @wraps(handler)
    async def wrapper(payload: ManagerCreate, *args, **kwargs):
        errors = _validate_manager_payload(payload)
        if errors:
            # Short-circuit invalid payloads before touching the database.
            return JSONResponse(status_code=400, content={"errors": errors, "error": errors})
        return await handler(payload, *args, **kwargs)

    return wrapper


def _raise_db_unavailable(exc: BaseException) -> None:
    logger.exception("Database error in managers API.", exc_info=exc)
    raise HTTPException(status_code=503, detail="Database unavailable") from exc


def _format_bulk_validation_errors(exc: ValidationError) -> list[dict[str, str]]:
    """Normalize Pydantic validation errors for bulk responses."""
    errors: list[dict[str, str]] = []
    for err in exc.errors():
        loc = [str(part) for part in err.get("loc", [])]
        field = loc[-1] if loc else "unknown"
        errors.append({"field": field, "message": err.get("msg", "Invalid value")})
    return errors


def _as_bulk_item_errors(errors: list[dict[str, str]]) -> list[BulkImportItemError]:
    return [BulkImportItemError(**error) for error in errors]


def _bulk_import_max_bytes() -> int:
    """Return the maximum allowed bulk import payload size in bytes."""
    raw_value = os.getenv("BULK_IMPORT_MAX_BYTES")
    if raw_value is None:
        return DEFAULT_BULK_IMPORT_MAX_BYTES
    try:
        value = int(raw_value)
    except ValueError:
        logger.warning("Invalid BULK_IMPORT_MAX_BYTES value: %s", raw_value)
        return DEFAULT_BULK_IMPORT_MAX_BYTES
    return max(value, 1)


def _parse_bulk_csv_payloads(content: str) -> tuple[list[dict[str, object]], list[str]]:
    """Parse CSV content into raw payload dictionaries."""
    reader = csv.DictReader(io.StringIO(content))
    if reader.fieldnames is None:
        return [], ["name"]
    normalized_fields = {
        (field or "").strip().lower(): field for field in reader.fieldnames if field
    }
    required_headers = ["name"]
    missing_headers = [header for header in required_headers if header not in normalized_fields]
    if missing_headers:
        return [], missing_headers
    name_key = normalized_fields["name"]
    cik_key = normalized_fields.get("cik")
    lei_key = normalized_fields.get("lei")
    aliases_key = normalized_fields.get("aliases")
    jurisdictions_key = normalized_fields.get("jurisdictions")
    tags_key = normalized_fields.get("tags")
    registry_ids_key = normalized_fields.get("registry_ids")
    payloads: list[dict[str, object]] = []
    for row in reader:
        # Skip rows that are entirely empty to avoid noise in error reports.
        if not any(value and str(value).strip() for value in row.values()):
            continue
        payloads.append(
            {
                "name": row.get(name_key, "") or "",
                "cik": (row.get(cik_key, "") or "").strip() if cik_key else None,
                "lei": (row.get(lei_key, "") or "").strip() if lei_key else None,
                "aliases": _json_array(row.get(aliases_key)) if aliases_key else [],
                "jurisdictions": (
                    _json_array(row.get(jurisdictions_key)) if jurisdictions_key else []
                ),
                "tags": _json_array(row.get(tags_key)) if tags_key else [],
                "registry_ids": _json_dict(row.get(registry_ids_key)) if registry_ids_key else {},
            }
        )
    return payloads, []


def _validate_bulk_records(
    raw_records: list[Any],
    source: str,
) -> tuple[list[tuple[int, ManagerCreate]], list[BulkImportFailure]]:
    """Validate bulk manager records and return valid payloads with failures."""
    valid_records: list[tuple[int, ManagerCreate]] = []
    failures: list[BulkImportFailure] = []
    for index, raw in enumerate(raw_records):
        if not isinstance(raw, dict):
            errors = [{"field": "record", "message": "Record must be an object."}]
            failures.append(BulkImportFailure(index=index, errors=_as_bulk_item_errors(errors)))
            logger.warning("Bulk import validation failed for record %s: %s", index, errors)
            continue
        try:
            payload = ManagerCreate(**raw)
        except ValidationError as exc:
            errors = _format_bulk_validation_errors(exc)
            failures.append(BulkImportFailure(index=index, errors=_as_bulk_item_errors(errors)))
            logger.warning("Bulk import validation failed for record %s: %s", index, errors)
            continue
        errors = _validate_manager_payload(payload)
        if errors:
            failures.append(BulkImportFailure(index=index, errors=_as_bulk_item_errors(errors)))
            if source == "csv":
                logger.warning(
                    "Bulk import CSV record missing required values for record %s: %s",
                    index,
                    errors,
                )
            else:
                logger.warning("Bulk import validation failed for record %s: %s", index, errors)
            continue
        if payload.cik is not None:
            # Store the same CIK used by duplicate checks. Missing CIKs must be
            # NULL so multiple records without identifiers can share the index.
            payload = payload.model_copy(update={"cik": payload.cik.strip() or None})
        valid_records.append((index, payload))
    return valid_records, failures


def _exclude_conflicting_bulk_ciks(
    conn: Any, valid_records: list[tuple[int, ManagerCreate]]
) -> tuple[list[tuple[int, ManagerCreate]], list[BulkImportFailure]]:
    """Keep only bulk records whose CIK is unique in the request and database."""
    accepted: list[tuple[int, ManagerCreate]] = []
    failures: list[BulkImportFailure] = []
    seen_ciks: set[str] = set()
    candidate_ciks = sorted(
        {payload.cik.strip() for _, payload in valid_records if payload.cik and payload.cik.strip()}
    )
    existing_ciks: set[str] = set()
    placeholder = "?" if isinstance(conn, sqlite3.Connection) else "%s"
    expression = _cik_lookup_expression(conn)
    for offset in range(0, len(candidate_ciks), BULK_CIK_LOOKUP_CHUNK_SIZE):
        batch = candidate_ciks[offset : offset + BULK_CIK_LOOKUP_CHUNK_SIZE]
        placeholders = ", ".join([placeholder] * len(batch))
        rows = conn.execute(
            f"SELECT DISTINCT {expression} FROM managers "
            f"WHERE {expression} IN ({placeholders})",
            tuple(batch),
        ).fetchall()
        existing_ciks.update(str(row[0]) for row in rows)
    for index, payload in valid_records:
        cik = payload.cik.strip() if payload.cik else ""
        if cik and (cik in seen_ciks or cik in existing_ciks):
            failures.append(
                BulkImportFailure(
                    index=index,
                    errors=_as_bulk_item_errors(
                        [{"field": "cik", "message": "A manager with this CIK already exists."}]
                    ),
                )
            )
            continue
        if cik:
            seen_ciks.add(cik)
        accepted.append((index, payload))
    return accepted, failures


def _bulk_request_error(field: str, message: str) -> JSONResponse:
    """Return a consistent 400 payload for bulk requests."""
    errors = [{"field": field, "message": message}]
    return JSONResponse(status_code=400, content={"errors": errors, "error": errors})


def _bulk_request_payload_too_large(max_bytes: int) -> JSONResponse:
    """Return a consistent 413 payload for bulk requests."""
    return JSONResponse(
        status_code=413,
        content={
            "errors": [
                {
                    "field": "body",
                    "message": f"Bulk import payload exceeds {max_bytes} bytes.",
                }
            ]
        },
    )


@router.post(
    "/managers",
    status_code=201,
    response_model=ManagerResponse,
    summary="Create a manager record",
    description=(
        "Validate the incoming manager details, store the record, and return the "
        "saved manager payload with its generated identifier."
    ),
    responses={
        400: {
            "model": ErrorResponse,
            "description": "Validation error",
            "content": {
                "application/json": {
                    "examples": {
                        "missing-name": {
                            "summary": "Missing name",
                            "value": {
                                "errors": [
                                    {
                                        "field": "name",
                                        "message": "Name is required.",
                                    }
                                ]
                            },
                        }
                    }
                }
            },
        },
        409: {
            "model": ErrorResponse,
            "description": "A manager with this CIK already exists, or legacy CIK duplicates require cleanup",
            "content": {
                "application/json": {
                    "examples": {
                        "duplicate-cik": {
                            "summary": "Duplicate CIK",
                            "value": {
                                "errors": [
                                    {
                                        "field": "cik",
                                        "message": "A manager with this CIK already exists.",
                                    }
                                ],
                                "error": [
                                    {
                                        "field": "cik",
                                        "message": "A manager with this CIK already exists.",
                                    }
                                ],
                            },
                        }
                    }
                }
            },
        },
    },
)
@_require_valid_manager
async def create_manager(
    payload: Annotated[
        ManagerCreate,
        Body(
            ...,
            examples={
                "basic": {
                    "summary": "New manager",
                    "value": {
                        "name": "Elliott Investment Management L.P.",
                        "cik": "0001791786",
                        "lei": "549300U3N12T57QLOU60",
                        "aliases": ["Elliott Management"],
                        "jurisdictions": ["us"],
                        "tags": ["activist"],
                        "registry_ids": {"fca_frn": "122927"},
                    },
                }
            },
        ),
    ],
):
    """Create a manager record after validating required fields."""
    if payload.cik is not None:
        payload = payload.model_copy(update={"cik": payload.cik.strip()})
    db_identity = os.getenv("DB_URL") or os.getenv("DB_PATH", "dev.db")
    conn = None
    try:
        conn = connect_db()
        # Ensure CIK uniqueness constraints exist before storing the record.
        try:
            _ensure_universe_schema(conn)
        except sqlite3.IntegrityError as exc:
            if "UNIQUE constraint failed: managers.cik" not in str(exc):
                raise
            errors = [
                {
                    "field": "cik",
                    "message": "Existing manager records share a CIK; clean up duplicate CIKs before creating managers.",
                }
            ]
            return JSONResponse(status_code=409, content={"errors": errors, "error": errors})
        if payload.cik and _manager_exists_for_cik(conn, payload.cik):
            errors = [{"field": "cik", "message": "A manager with this CIK already exists."}]
            return JSONResponse(status_code=409, content={"errors": errors, "error": errors})
        try:
            manager_id = _insert_manager(conn, payload)
        except DB_ERROR_TYPES as exc:
            if payload.cik and _is_cik_unique_violation(exc):
                errors = [{"field": "cik", "message": "A manager with this CIK already exists."}]
                return JSONResponse(status_code=409, content={"errors": errors, "error": errors})
            raise
        invalidate_cache_prefix("managers")
        row = _fetch_manager(conn, db_identity, manager_id)
    except DB_ERROR_TYPES as exc:
        _raise_db_unavailable(exc)
    finally:
        if conn is not None:
            conn.close()
    if row is not None:
        return _to_manager_response(row)
    return ManagerResponse(
        manager_id=manager_id,
        name=payload.name,
        cik=payload.cik,
        lei=payload.lei,
        aliases=payload.aliases,
        jurisdictions=payload.jurisdictions,
        tags=payload.tags,
        registry_ids=payload.registry_ids,
        quality_flags=[],
        created_at=None,
        updated_at=None,
    )


@router.get(
    "/managers",
    response_model=ManagerListResponse,
    summary="List managers",
    description="Return a paginated list of managers with total count metadata.",
    # Document query validation errors for OpenAPI consumers.
    responses={
        400: {
            "model": ErrorResponse,
            "description": "Validation error",
            "content": {
                "application/json": {
                    "examples": {
                        "invalid-limit": {
                            "summary": "Invalid limit",
                            "value": {
                                "errors": [
                                    {
                                        "field": "limit",
                                        "message": "ensure this value is greater than or equal to 1",
                                    }
                                ]
                            },
                        }
                    }
                }
            },
        }
    },
    openapi_extra={
        "responses": {
            "200": {
                "content": {
                    "application/json": {
                        "examples": {
                            "investment-managers": {
                                "summary": "Investment manager page",
                                "value": {
                                    "items": [
                                        {
                                            "manager_id": 101,
                                            "name": "Elliott Investment Management L.P.",
                                            "cik": "0001791786",
                                            "lei": "549300U3N12T57QLOU60",
                                            "aliases": ["Elliott Management"],
                                            "jurisdictions": ["us"],
                                            "tags": ["activist"],
                                            "registry_ids": {"fca_frn": "122927"},
                                            "created_at": "2026-02-01T10:00:00Z",
                                            "updated_at": "2026-02-01T10:00:00Z",
                                        }
                                    ],
                                    "total": 1,
                                    "limit": 25,
                                    "offset": 0,
                                },
                            }
                        }
                    }
                }
            }
        }
    },
)
async def list_managers(
    limit: int = Query(
        25,
        ge=1,
        le=100,
        description="Maximum number of managers to return",
    ),
    offset: int = Query(
        0,
        ge=0,
        description="Number of managers to skip",
    ),
    jurisdiction: str | None = Query(None, description="Filter managers by jurisdiction"),
    tag: str | None = Query(None, description="Filter managers by tag"),
    search: str | None = Query(
        None,
        description="Case-insensitive substring match on manager names and aliases",
    ),
    name: str | None = Query(
        None,
        description="Case-insensitive manager-name prefix match",
    ),
):
    """Return a paginated list of managers."""
    db_identity = os.getenv("DB_URL") or os.getenv("DB_PATH", "dev.db")
    conn = None
    try:
        conn = connect_db()
        # Ensure the table exists so empty databases still return metadata.
        _ensure_manager_table(conn)
        normalized_jurisdiction = jurisdiction.strip() or None if jurisdiction else None
        normalized_tag = tag.strip() or None if tag else None
        normalized_search = search.strip() or None if search else None
        normalized_name = name.strip() or None if name else None
        total = _count_managers(
            conn,
            db_identity,
            normalized_jurisdiction,
            normalized_tag,
            normalized_search,
            normalized_name,
        )
        # Default to a 25-row page while preserving the client-requested limit in metadata.
        remaining = max(total - offset, 0)
        page_limit = min(limit, remaining)
        if page_limit:
            rows = _fetch_managers(
                conn,
                db_identity,
                page_limit,
                offset,
                normalized_jurisdiction,
                normalized_tag,
                normalized_search,
                normalized_name,
            )
        else:
            rows = []
        response_limit = limit
    except DB_ERROR_TYPES as exc:
        _raise_db_unavailable(exc)
    finally:
        if conn is not None:
            conn.close()
    items = [_to_manager_response(row) for row in rows]
    return ManagerListResponse(items=items, total=total, limit=response_limit, offset=offset)


@router.post(
    "/api/managers/bulk",
    status_code=200,
    response_model=BulkImportResponse,
    summary="Bulk import managers",
    description=(
        "Import multiple managers in a single request, returning per-record successes "
        "and validation failures."
    ),
    openapi_extra={
        "requestBody": {
            "required": True,
            "content": {
                "application/json": {
                    "schema": {
                        "type": "array",
                        "items": {"$ref": "#/components/schemas/ManagerCreate"},
                    },
                    "examples": {
                        "basic": {
                            "value": [
                                {
                                    "name": "Elliott Investment Management L.P.",
                                    "cik": "0001791786",
                                    "jurisdictions": ["us"],
                                    "tags": ["activist"],
                                }
                            ]
                        }
                    },
                },
                "text/csv": {"schema": {"type": "string", "format": "binary"}},
                "application/csv": {"schema": {"type": "string", "format": "binary"}},
            },
        }
    },
    responses={
        400: {
            "model": ErrorResponse,
            "description": "Validation error",
        },
        409: {
            "model": ErrorResponse,
            "description": "Legacy duplicate CIKs require cleanup before bulk imports",
        },
    },
)
async def bulk_import_managers(
    request: Request,
):
    """Bulk import managers from JSON or CSV inputs."""
    content_type = (request.headers.get("content-type") or "").lower()
    max_bytes = _bulk_import_max_bytes()
    content_length = request.headers.get("content-length")
    if content_length:
        try:
            declared_length = int(content_length)
        except ValueError:
            declared_length = None
        # Check declared size up front to avoid loading oversized bodies into memory.
        if declared_length is not None and declared_length > max_bytes:
            logger.warning(
                "Bulk import payload too large: %s bytes (max %s).",
                declared_length,
                max_bytes,
            )
            return _bulk_request_payload_too_large(max_bytes)

    raw_bytes = await request.body()
    if len(raw_bytes) > max_bytes:
        logger.warning(
            "Bulk import payload too large: %s bytes (max %s).",
            len(raw_bytes),
            max_bytes,
        )
        return _bulk_request_payload_too_large(max_bytes)

    source = "csv" if "csv" in content_type else "json"
    if "csv" in content_type:
        try:
            decoded = raw_bytes.decode("utf-8-sig")
        except UnicodeDecodeError:
            return _bulk_request_error("body", "CSV payload must be UTF-8 encoded.")
        raw_records, missing_headers = _parse_bulk_csv_payloads(decoded)
        if missing_headers:
            message = "CSV payload missing required headers: " + ", ".join(missing_headers)
            logger.warning("Bulk import CSV missing required headers: %s", missing_headers)
            return _bulk_request_error("body", message)
    else:
        try:
            body = json.loads(raw_bytes)
        except (UnicodeDecodeError, json.JSONDecodeError):
            return _bulk_request_error("body", "Request body must be valid JSON.")
        if not isinstance(body, list):
            return _bulk_request_error("body", "Request body must be a JSON array.")
        raw_records = body

    if not raw_records:
        return _bulk_request_error("body", "No manager records were provided.")

    # Validate all records before inserting any to satisfy bulk import guarantees.
    valid_records, failures = _validate_bulk_records(raw_records, source)

    conn = None
    successes: list[BulkImportSuccess] = []
    schema_ready = False
    postgres_autocommit_restored = False
    db_error: BaseException | None = None
    try:
        if valid_records:
            conn = connect_db()
            _ensure_universe_schema(conn, check_legacy_ciks=True)
            schema_ready = True
            valid_records, cik_failures = _exclude_conflicting_bulk_ciks(conn, valid_records)
            failures.extend(cik_failures)
            if not isinstance(conn, sqlite3.Connection) and getattr(conn, "autocommit", False):
                conn.autocommit = False
                postgres_autocommit_restored = True
            # An outer transaction keeps releasing SQLite savepoints from committing
            # records before the entire batch has finished.
            if isinstance(conn, sqlite3.Connection) and not conn.in_transaction:
                conn.execute("BEGIN")
            for index, payload in valid_records:
                if payload.cik:
                    conn.execute("SAVEPOINT bulk_manager_insert")
                try:
                    manager_id = _insert_manager(conn, payload, commit=False)
                except DB_ERROR_TYPES as exc:
                    if not payload.cik or not _is_cik_unique_violation(exc):
                        raise
                    conn.execute("ROLLBACK TO SAVEPOINT bulk_manager_insert")
                    conn.execute("RELEASE SAVEPOINT bulk_manager_insert")
                    failures.append(
                        BulkImportFailure(
                            index=index,
                            errors=_as_bulk_item_errors(
                                [
                                    {
                                        "field": "cik",
                                        "message": "A manager with this CIK already exists.",
                                    }
                                ]
                            ),
                        )
                    )
                    continue
                if payload.cik:
                    conn.execute("RELEASE SAVEPOINT bulk_manager_insert")
                successes.append(
                    BulkImportSuccess(
                        index=index,
                        manager=ManagerResponse(
                            manager_id=manager_id,
                            name=payload.name,
                            cik=payload.cik,
                            lei=payload.lei,
                            aliases=payload.aliases,
                            jurisdictions=payload.jurisdictions,
                            tags=payload.tags,
                            registry_ids=payload.registry_ids,
                            quality_flags=[],
                            created_at=None,
                            updated_at=None,
                        ),
                    )
                )
            conn.commit()
            invalidate_cache_prefix("managers")
    except (LegacyDuplicateCikError, *DB_ERROR_TYPES) as exc:
        db_error = exc
        if conn is not None:
            try:
                conn.rollback()
            except DB_ERROR_TYPES as rollback_error:
                logger.warning("Bulk import rollback failed: %s", rollback_error)
    finally:
        if conn is not None:
            if postgres_autocommit_restored:
                try:
                    conn.autocommit = True
                except DB_ERROR_TYPES as cleanup_error:
                    logger.warning("Bulk import autocommit restoration failed: %s", cleanup_error)
                    if db_error is None:
                        db_error = cleanup_error
            try:
                conn.close()
            except DB_ERROR_TYPES as cleanup_error:
                logger.warning("Bulk import connection close failed: %s", cleanup_error)
                if db_error is None:
                    db_error = cleanup_error

    if db_error is not None:
        if not schema_ready and (
            isinstance(db_error, LegacyDuplicateCikError) or _is_cik_unique_violation(db_error)
        ):
            errors = [
                {
                    "field": "cik",
                    "message": "Existing manager records share a CIK; clean up duplicate CIKs before importing managers.",
                }
            ]
            return JSONResponse(status_code=409, content={"errors": errors, "error": errors})
        _raise_db_unavailable(db_error)

    return BulkImportResponse(
        total=len(raw_records),
        succeeded=len(successes),
        failed=len(failures),
        successes=successes,
        failures=failures,
    )


@router.post(
    "/managers/import/universe",
    status_code=200,
    response_model=UniverseImportResponse,
    summary="Import manager universe records",
    description=(
        "Import a JSON array of manager universe records with CIK-based upsert behavior. "
        "Valid records create or update managers by CIK; invalid records are skipped."
    ),
)
async def import_manager_universe(
    records: Annotated[Any, Body(..., description="Array of manager records")],
):
    """Upsert manager universe records using CIK as the unique key."""
    if not isinstance(records, list):
        return _bulk_request_error("body", "Request body must be a JSON array.")

    if not records:
        return UniverseImportResponse(created=0, updated=0, skipped=0)

    conn = None
    created = 0
    updated = 0
    skipped = 0
    try:
        conn = connect_db()
        _ensure_universe_schema(conn)
        for index, record in enumerate(records):
            if not isinstance(record, dict):
                skipped += 1
                logger.warning("Universe import skipped record %s: record must be an object", index)
                continue
            name = str(record.get("name", "")).strip()
            cik = normalize_cik(record.get("cik"))
            jurisdiction = str(record.get("jurisdiction", "")).strip().lower()
            if not name or not cik or not jurisdiction:
                skipped += 1
                logger.warning(
                    "Universe import skipped record %s: requires name, cik, jurisdiction",
                    index,
                )
                continue

            existed = _manager_exists_for_cik(conn, cik)
            if existed:
                updated += 1
            else:
                created += 1

            _upsert_universe_record(conn, name, cik, jurisdiction)

        conn.commit()
        invalidate_cache_prefix("managers")
    except DB_ERROR_TYPES as exc:
        _raise_db_unavailable(exc)
    finally:
        if conn is not None:
            conn.close()

    return UniverseImportResponse(created=created, updated=updated, skipped=skipped)


@router.get(
    "/managers/stats",
    response_model=ManagerStatsResponse,
    summary="Retrieve manager universe stats",
    description=(
        "Return aggregate manager counts across the current universe, including "
        "jurisdiction and tag breakdowns."
    ),
)
async def get_manager_stats():
    """Return aggregate manager universe statistics."""
    conn = None
    try:
        conn = connect_db()
        _ensure_manager_table(conn)
        rows = _fetch_manager_stats_rows(conn)
    except DB_ERROR_TYPES as exc:
        _raise_db_unavailable(exc)
    finally:
        if conn is not None:
            conn.close()

    return _build_manager_stats(rows)


@router.get(
    "/managers/{id}",
    response_model=ManagerResponse,
    summary="Retrieve a manager",
    description="Return a single manager by id.",
    # Surface path validation errors alongside the 404 response.
    responses={
        400: {
            "model": ErrorResponse,
            "description": "Validation error",
            "content": {
                "application/json": {
                    "examples": {
                        "invalid-id": {
                            "summary": "Invalid id",
                            "value": {
                                "errors": [
                                    {
                                        "field": "id",
                                        "message": "ensure this value is greater than or equal to 1",
                                    }
                                ]
                            },
                        }
                    }
                }
            },
        },
        404: {
            "model": NotFoundResponse,
            "description": "Manager not found",
            "content": {
                "application/json": {
                    "examples": {
                        "missing": {
                            "summary": "Missing manager",
                            "value": {"detail": "Manager not found"},
                        }
                    }
                }
            },
        },
    },
    openapi_extra={
        "responses": {
            "200": {
                "content": {
                    "application/json": {
                        "examples": {
                            "investment-manager": {
                                "summary": "Investment manager",
                                "value": {
                                    "manager_id": 101,
                                    "name": "Elliott Investment Management L.P.",
                                    "cik": "0001791786",
                                    "lei": "549300U3N12T57QLOU60",
                                    "aliases": ["Elliott Management"],
                                    "jurisdictions": ["us"],
                                    "tags": ["activist"],
                                    "registry_ids": {"fca_frn": "122927"},
                                    "created_at": "2026-02-01T10:00:00Z",
                                    "updated_at": "2026-02-01T10:00:00Z",
                                },
                            }
                        }
                    }
                }
            }
        }
    },
)
async def get_manager(
    id: int = Path(..., ge=1, description="Manager identifier"),
):
    """Return a manager by id or raise 404."""
    db_identity = os.getenv("DB_URL") or os.getenv("DB_PATH", "dev.db")
    conn = None
    try:
        conn = connect_db()
        # Ensure the table exists before attempting the lookup.
        _ensure_manager_table(conn)
        row = _fetch_manager(conn, db_identity, id)
    except DB_ERROR_TYPES as exc:
        _raise_db_unavailable(exc)
    finally:
        if conn is not None:
            conn.close()
    if row is None:
        raise HTTPException(status_code=404, detail="Manager not found")
    return _to_manager_response(row)


SIMILARITY_BASES = ("jaccard", "cosine")


def _configured_similarity_basis() -> str:
    """Return the configured default similarity basis, keeping Jaccard as fallback."""
    raw = os.getenv("MANAGER_SIMILARITY_DEFAULT_BASIS")
    if raw is None:
        return "jaccard"
    candidate = raw.strip().lower()
    if candidate in SIMILARITY_BASES:
        return candidate
    logger.warning("Invalid MANAGER_SIMILARITY_DEFAULT_BASIS value: %s", raw)
    return "jaccard"


@router.get("/managers/{id}/similar", summary="List similar managers")
async def get_similar_managers(
    id: int = Path(..., ge=1, description="Manager identifier"),
    limit: int = Query(10, ge=1, le=100),
    basis: str | None = Query(
        None,
        pattern="^(jaccard|cosine)$",
        description="Similarity basis; defaults to MANAGER_SIMILARITY_DEFAULT_BASIS (jaccard).",
    ),
):
    """Return the strongest holding-overlap or embedding-cosine peers for a manager."""
    basis = basis or _configured_similarity_basis()
    conn = None
    try:
        conn = connect_db()
        _ensure_manager_table(conn)
        manager_column = _manager_id_column(conn)
        if (
            conn.execute(
                f"SELECT 1 FROM managers WHERE {manager_column} = {'?' if isinstance(conn, sqlite3.Connection) else '%s'}",
                (id,),
            ).fetchone()
            is None
        ):
            raise HTTPException(status_code=404, detail="Manager not found")
        ensure_manager_similarity_table(conn)
        ph = "?" if isinstance(conn, sqlite3.Connection) else "%s"
        score_column = "cosine" if basis == "cosine" else "jaccard"
        rows = conn.execute(
            "SELECT CASE WHEN manager_id_a = "
            + ph
            + " THEN manager_id_b ELSE manager_id_a END, "
            + score_column
            + ", jaccard, cosine, overlap_count, union_count "
            "FROM manager_similarity WHERE (manager_id_a = "
            + ph
            + " OR manager_id_b = "
            + ph
            + ") AND "
            + score_column
            + " IS NOT NULL ORDER BY "
            + score_column
            + " DESC, overlap_count DESC",
            (id, id, id),
        ).fetchall()
        finite_rows = [
            row
            for row in rows
            if all(
                value is None or math.isfinite(float(value)) for value in (row[1], row[2], row[3])
            )
        ]
        return {
            "items": [
                {
                    "manager_id": int(row[0]),
                    "basis": basis,
                    "score": float(row[1]),
                    "jaccard": float(row[2]),
                    "cosine": float(row[3]) if row[3] is not None else None,
                    "overlap_count": int(row[4]),
                    "union_count": int(row[5]),
                }
                for row in finite_rows[:limit]
            ]
        }
    except DB_ERROR_TYPES as exc:
        _raise_db_unavailable(exc)
    finally:
        if conn is not None:
            conn.close()


@router.patch(
    "/managers/{id}",
    response_model=ManagerResponse,
    summary="Update a manager",
    description="Partially update manager fields and return the updated record.",
    responses={
        400: {"model": ErrorResponse, "description": "Validation error"},
        404: {"model": NotFoundResponse, "description": "Manager not found"},
    },
    openapi_extra={
        "requestBody": {
            "content": {
                "application/json": {
                    "examples": {
                        "update-tags-and-lei": {
                            "summary": "Update manager metadata",
                            "value": {
                                "lei": "549300U3N12T57QLOU60",
                                "aliases": ["Elliott Management"],
                                "tags": ["event-driven"],
                            },
                        }
                    }
                }
            }
        }
    },
)
async def patch_manager(
    payload: ManagerUpdate,
    id: int = Path(..., ge=1, description="Manager identifier"),
):
    """Partially update a manager by id."""
    errors = _validate_manager_update_payload(payload)
    if errors:
        return JSONResponse(status_code=400, content={"errors": errors, "error": errors})

    db_identity = os.getenv("DB_URL") or os.getenv("DB_PATH", "dev.db")
    conn = None
    try:
        conn = connect_db()
        _ensure_manager_table(conn)
        updated = _update_manager(conn, id, payload)
        if not updated:
            raise HTTPException(status_code=404, detail="Manager not found")
        # Invalidate BEFORE re-fetching: _fetch_manager is cache_query-wrapped, so fetching
        # first can hand back the pre-update row from a still-warm cache entry (e.g. a UI
        # that GET the manager right before editing it) and this endpoint would then return
        # its own stale data despite the update already being committed. patch_manager_tags
        # already does it in this order; this brings patch_manager in line with it.
        invalidate_cache_prefix("managers")
        row = _fetch_manager(conn, db_identity, id)
    except DB_ERROR_TYPES as exc:
        _raise_db_unavailable(exc)
    finally:
        if conn is not None:
            conn.close()

    if row is None:
        raise HTTPException(status_code=404, detail="Manager not found")
    return _to_manager_response(row)


@router.patch(
    "/managers/{id}/tags",
    response_model=ManagerResponse,
    summary="Append or remove manager tags",
    description=(
        "Append and/or remove tags for a manager without replacing the rest of the record."
    ),
    responses={
        400: {"model": ErrorResponse, "description": "Validation error"},
        404: {"model": NotFoundResponse, "description": "Manager not found"},
    },
    openapi_extra={
        "requestBody": {
            "content": {
                "application/json": {
                    "examples": {
                        "add-and-remove-tags": {
                            "summary": "Append and remove tags",
                            "value": {"add": ["event-driven"], "remove": ["activist"]},
                        }
                    }
                }
            }
        }
    },
)
async def patch_manager_tags(
    payload: ManagerTagsPatch,
    id: int = Path(..., ge=1, description="Manager identifier"),
):
    """Append/remove manager tags and return the updated manager."""
    add_tags = _normalize_tags(payload.add)
    remove_tags = _normalize_tags(payload.remove)
    if not add_tags and not remove_tags:
        errors = [
            {
                "field": "body",
                "message": "At least one non-empty tag must be provided in add or remove.",
            }
        ]
        return JSONResponse(status_code=400, content={"errors": errors, "error": errors})

    db_identity = os.getenv("DB_URL") or os.getenv("DB_PATH", "dev.db")
    conn = None
    try:
        conn = connect_db()
        _ensure_manager_table(conn)
        existing_row = _fetch_manager(conn, db_identity, id)
        if existing_row is None:
            raise HTTPException(status_code=404, detail="Manager not found")

        existing_tags = _json_array(existing_row[6])
        merged_tags = _merge_tags(existing_tags, add_tags, remove_tags)
        if merged_tags != existing_tags:
            _update_manager(conn, id, ManagerUpdate.model_validate({"tags": merged_tags}))
            invalidate_cache_prefix("managers")
            row = _fetch_manager(conn, db_identity, id)
        else:
            row = existing_row
    except DB_ERROR_TYPES as exc:
        _raise_db_unavailable(exc)
    finally:
        if conn is not None:
            conn.close()

    if row is None:
        raise HTTPException(status_code=404, detail="Manager not found")
    return _to_manager_response(row)


@router.delete(
    "/managers/{id}",
    status_code=204,
    summary="Delete a manager",
    description="Delete a manager by id.",
    responses={404: {"model": NotFoundResponse, "description": "Manager not found"}},
)
async def delete_manager(
    id: int = Path(..., ge=1, description="Manager identifier"),
):
    """Delete a manager by id."""
    conn = None
    try:
        conn = connect_db()
        _ensure_manager_table(conn)
        result = delete_manager_data(conn, id)
        if not result.deleted:
            raise HTTPException(status_code=404, detail="Manager not found")
        invalidate_cache_prefix("managers")
    except AmbiguousManagerObjectsError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except ManagerObjectDeletionError as exc:
        raise HTTPException(
            status_code=503,
            detail="Manager deletion could not complete object-storage cleanup; retry is safe.",
        ) from exc
    except DB_ERROR_TYPES as exc:
        _raise_db_unavailable(exc)
    finally:
        if conn is not None:
            conn.close()
    return Response(status_code=204)


# Commit-message checklist:
# - [ ] type is accurate (fix, test, chore)
# - [ ] scope is clear (managers)
# - [ ] summary is concise and imperative
