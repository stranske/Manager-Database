import concurrent.futures


class InlineExecutor(concurrent.futures.Executor):
    def __init__(self, **kwargs):
        pass

    def submit(self, fn, /, *args, **kwargs):
        future = concurrent.futures.Future()
        try:
            future.set_result(fn(*args, **kwargs))
        except BaseException as exc:
            future.set_exception(exc)
        return future


concurrent.futures.ThreadPoolExecutor = InlineExecutor
