import hashlib
import json
import tarfile
from pathlib import Path

root = Path.cwd()
evidence = root / "docs/evidence/issue-1750-dialect-boundaries"
for name, archive_name in [("manifest.json", "validation.tar.gz"), ("acceptance-manifest.json", "acceptance-validation.tar.gz")]:
    manifest = json.loads((evidence / name).read_text())
    archive = evidence / archive_name
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == manifest["archive_sha256"]
    with tarfile.open(archive) as bundle:
        members = {m.name: m for m in bundle.getmembers() if m.isfile()}
        assert members.keys() == manifest["archive_members"].keys()
        for member_name, member in members.items():
            with bundle.extractfile(member) as stream:
                assert hashlib.sha256(stream.read()).hexdigest() == manifest["archive_members"][member_name], member_name
    for path, expected in manifest["current_inputs"].items():
        assert hashlib.sha256((root / path).read_bytes()).hexdigest() == expected, path
    print(f"{name}: {len(members)} archive members and {len(manifest['current_inputs'])} current inputs verified")
