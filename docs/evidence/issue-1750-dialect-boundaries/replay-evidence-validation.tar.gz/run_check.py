import json
import os
import subprocess
import sys
import time
from pathlib import Path

output = Path(__file__).parent
tag, *argv = sys.argv[1:]
overrides = {"PYTEST_ADDOPTS": "-m 'not slow'"} if tag == "replay" else {}
if tag == "black-inline":
    overrides = {"PYTHONPATH": str(output / "black-runtime")}
env = os.environ.copy()
env.update(overrides)
started = time.monotonic()
with (output / f"{tag}.log").open("w") as log:
    try:
        result = subprocess.run(argv, stdout=log, stderr=subprocess.STDOUT, env=env, timeout=60, check=False)
        code = result.returncode
    except subprocess.TimeoutExpired:
        code = 124
receipt = {"argv": argv, "cwd": str(Path.cwd()), "exit": code, "env_overrides": overrides, "elapsed_seconds": time.monotonic() - started}
(output / f"{tag}.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt))
print((output / f"{tag}.log").read_text())
sys.exit(code)
