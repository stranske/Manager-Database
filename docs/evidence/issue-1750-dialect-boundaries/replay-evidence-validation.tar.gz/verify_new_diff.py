import subprocess

paths = ["tests/test_manager_dialect_replay_evidence.py", "docs/evidence/issue-1750-dialect-boundaries/replay-evidence.md"]
for path in paths:
    result = subprocess.run(["git", "diff", "--no-index", "--check", "/dev/null", path], capture_output=True, text=True, check=False)
    assert result.returncode in (0, 1), (path, result.returncode)
    assert not result.stdout and not result.stderr, (path, result.stdout, result.stderr)
    print(f"PASS: whitespace check for {path}")
