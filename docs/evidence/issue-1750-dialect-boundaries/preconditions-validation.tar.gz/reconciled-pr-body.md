Related to #1750. Preserve the broader coverage initiative OPEN below 90%.

Six named tests cover PostgreSQL adapter boundaries: array filter parameters, native-array upsert, missing insert identity, JSONB registry updates, preservation of conflict flags, and missing count results. Production is unchanged. RecordingConnection inspects SQL/arguments; this does not claim live PostgreSQL, deployed API, or concurrency behavior.

## Tasks and acceptance

- [x] Six focused cases pass. Each actual function-scoped production mutation fails the exact named test; byte-identical restoration passes. Caller bytes remain unchanged, and output reuse fails before mutation.
- [x] Full matched suite: 1875→1881 PASS, unchanged 24 existing UI/auth FAIL and 21 SKIP. Both commands exit1, zero changed old outcomes, exactly six new passing nodes.
- [x] Coverage12376→12384/14243 statements (86.8918065→86.9479744%). Same116-source-file universe/82 excluded lines/no covered-line regression. Managers816→824/826; remaining lines330/1441.
- [x] Fresh last500 source-touching commit ranking selects managers first:19 repair-subject proxy matches/61touches/10baseline missing statements. Proxy is not verified escaped-defect history.
- [x] FullBlack399files, focusedRuff, three replay modules together under mypy, diff check and all59raw archive members/four current input hashes pass.

## Acceptance criteria

- [x] **Tests**
  - [x] Added focused checks for database query parameters, count results, inserts, updates, and missing data, using a recording connection rather than a live database.
  - [x] Added replay checks for six database-adapter cases, including validation of expected test results and restoration of source files.
  - [x] Added safeguards for interrupted or invalid replay runs, mismatched inputs, and incomplete evidence; these checks verify that no success is reported when validation fails.
- [x] **Documentation**
  - [x] Added verification results, reproduction instructions, and archived evidence. Reports note unchanged production code, limitations in broader test results, and that the related issue remains open.

Reconciliation of commits d812e3b, b85e382, and b190853: 51 focused tests pass with slow tests excluded. All four evidence archives and current-input bindings verify (59/4, 49/10, 67/12, and 8/5 members/inputs). The original full-suite and coverage measurements remain historical; no new global coverage percentage or full-suite PASS is claimed. #1750 remains OPEN below 90%.

## Reproduce

```sh
python3 -m pytest tests/test_manager_dialect_boundaries.py -q -o addopts=
python3 docs/evidence/issue-1750-dialect-boundaries/replay_dialect_boundaries.py --output /tmp/new-manager-dialect-proof
python3 -m pytest tests -q --cov --cov-report=json:coverage.json
```

Complete raw console/JUnit/coverage/argv/cwd/exits, ranking, production/test/replay snapshots and twelve mutation phase receipts are committed in docs/evidence/issue-1750-dialect-boundaries/validation.tar.gz, bound by manifest.json and comparison.json. Python3.12.2 installed local environment; no hosted dependency parity/fullsuitePASS/providerPASS claim.

Matching Codex keepalive owns hosted checks/review. Closer requires complete exact-head expected topology, zero active threads, seven-minute latest-activity floor, guarded merge and actual verify:compare/bounded chunk disposition. No source1750 closure or Workflows key3820 acceptance is inferred.


<!-- This is an auto-generated comment: release notes by coderabbit.ai -->
## Summary by CodeRabbit

* **Tests**
  * Added focused checks for database query parameters, count results, inserts, updates, and missing data, using a recording connection rather than a live database.
  * Added replay checks for six database-adapter cases, including validation of expected test results and restoration of source files.
  * Added safeguards for interrupted or invalid replay runs, mismatched inputs, and incomplete evidence; these checks verify that no success is reported when validation fails.
* **Documentation**
  * Added verification results, reproduction instructions, and archived evidence. Reports note unchanged production code, limitations in broader test results, and that the related issue remains open.
<!-- end of auto-generated comment: release notes by coderabbit.ai -->
