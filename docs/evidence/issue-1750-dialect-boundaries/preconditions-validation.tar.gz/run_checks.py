"""Preserve command receipts for the replay precondition follow-up."""

import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path('/home/runner/work/Manager-Database/Manager-Database')
OUT = Path(__file__).resolve().parent
TESTS = [
    'tests/test_manager_dialect_boundaries.py',
    'tests/test_manager_dialect_contracts.py',
    'tests/test_manager_dialect_replay_guard.py',
    'tests/test_manager_dialect_replay_evidence.py',
    'tests/test_manager_dialect_replay_interruptions.py',
    'tests/test_manager_dialect_replay_preconditions.py',
]
DRIVER = 'docs/evidence/issue-1750-dialect-boundaries/replay_dialect_boundaries.py'


def run(name, argv, timeout=45, env=None):
    receipt = {'argv': argv, 'cwd': str(ROOT), 'timeout_seconds': timeout}
    if env is not None:
        receipt['runtime_pythonpath'] = env['PYTHONPATH']
    with (OUT / f'{name}.log').open('w') as log:
        try:
            result = subprocess.run(argv, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
                                    check=False, timeout=timeout, env=env)
            receipt['exit'] = result.returncode
        except subprocess.TimeoutExpired:
            receipt['exit'] = None
            receipt['timed_out'] = True
    (OUT / f'{name}.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(f'{name}: {receipt}', flush=True)
    return receipt.get('exit') == 0


assert run('focused', [sys.executable, '-m', 'pytest', *TESTS, '-q', '-o', 'addopts=',
                       '-m', 'not slow', f'--junitxml={OUT / "focused.xml"}'])
assert run('ruff', [sys.executable, '-m', 'ruff', 'check', *TESTS, DRIVER])
assert run('mypy', [sys.executable, '-m', 'mypy', '--follow-imports=silent', *TESTS, DRIVER])
assert run('diff', ['git', 'diff', '--check'])
black = ['black', '--check', '--line-length', '100', '--exclude',
         r'(\.workflows-lib|node_modules)', '.']
if not run('black-ordinary', black):
    environment = os.environ.copy()
    environment['PYTHONPATH'] = str(OUT / 'black-runtime')
    assert run('black', black, env=environment)
