"""Minimal FastAPI app providing /chat and health endpoints."""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import importlib
import json
import logging
import os
import time
import uuid
from collections import defaultdict, deque
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import date
from threading import Lock
from typing import Any, cast

import boto3
from botocore.config import Config as BotoConfig
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, Response
from prometheus_client import CONTENT_TYPE_LATEST, Histogram, generate_latest
from pydantic import BaseModel, ConfigDict, Field

from adapters.base import connect_db, get_placeholder, is_sqlite, manager_id_column, table_exists
from api.activism import router as activism_router
from api.alerts import router as alerts_router
from api.data import router as data_router
from api.managers import router as managers_router
from api.memory_profiler import start_memory_profiler, stop_memory_profiler
from api.search import SearchEntityType, SearchResult, universal_search
from api.signals import router as signals_router
from config import load_runtime_config
from llm.langsmith_fleet import (
    ChatFleetContext,
    TokenUsage,
    record_chat_event,
    record_feedback_event,
)
from llm.tracing import maybe_enable_langsmith_tracing
from utils.numeric import finite_float_or_none

app = FastAPI()
# Tag manager endpoints so they group clearly in the Swagger UI.
app.include_router(managers_router, tags=["Managers"])
app.include_router(data_router, tags=["Data"])
app.include_router(alerts_router, tags=["Alerts"])
app.include_router(activism_router, tags=["Activism"])
app.include_router(signals_router, tags=["Signals"])
_APP_EXECUTOR = ThreadPoolExecutor(max_workers=4)
# Allow concurrent health checks without serializing every dependency probe.
_HEALTH_EXECUTOR = ThreadPoolExecutor(max_workers=3)


@dataclass(frozen=True)
class HealthClock:
    """Centralize time sources to enable deterministic health check tests."""

    perf_counter: Callable[[], float]
    monotonic: Callable[[], float]
    sleep: Callable[[float], None]


HEALTH_CLOCK = HealthClock(time.perf_counter, time.monotonic, time.sleep)
APP_START_TIME = HEALTH_CLOCK.monotonic()
HEALTH_CHECK_DURATION = Histogram(
    "health_check_duration_seconds",
    "Health check latency by endpoint.",
    labelnames=("endpoint",),
)
logger = logging.getLogger(__name__)


def get_health_executor():
    """Return a working health executor, creating a new one if needed."""
    global _HEALTH_EXECUTOR
    if _HEALTH_EXECUTOR._shutdown:
        _HEALTH_EXECUTOR = ThreadPoolExecutor(max_workers=3)
    return _HEALTH_EXECUTOR


class CircuitBreaker:
    """Track consecutive failures and open after a threshold."""

    def __init__(
        self,
        failure_threshold: int = 3,
        reset_timeout_s: float = 30.0,
        monotonic_fn: Callable[[], float] | None = None,
    ) -> None:
        self._failure_threshold = failure_threshold
        self._reset_timeout_s = reset_timeout_s
        self._consecutive_failures = 0
        self._opened_at: float | None = None
        # Allow tests to inject a deterministic clock without patching globals.
        self._monotonic = monotonic_fn or HEALTH_CLOCK.monotonic
        self._lock = Lock()

    def is_open(self) -> bool:
        """Return True when the breaker is open and requests should be skipped."""
        with self._lock:
            if self._opened_at is None:
                return False
            if (self._monotonic() - self._opened_at) >= self._reset_timeout_s:
                self._opened_at = None
                self._consecutive_failures = 0
                return False
            return True

    def record_success(self) -> None:
        """Reset the breaker after a successful call."""
        with self._lock:
            self._consecutive_failures = 0
            self._opened_at = None

    def record_failure(self) -> None:
        """Track a failure and open the breaker if needed."""
        with self._lock:
            self._consecutive_failures += 1
            if self._consecutive_failures >= self._failure_threshold:
                if self._opened_at is None:
                    self._opened_at = self._monotonic()


def _health_timeout_seconds(env_name: str, default: float) -> float:
    """Read a finite positive timeout, using the default for invalid configuration."""
    timeout = finite_float_or_none(os.getenv(env_name))
    return timeout if timeout is not None and timeout > 0 else default


def _circuit_breaker_reset_seconds() -> float:
    """Return the reset timeout (default 30s), retaining the 1s minimum."""
    return max(_health_timeout_seconds("HEALTH_CIRCUIT_RESET_S", 30.0), 1.0)


_MINIO_CIRCUIT = CircuitBreaker(reset_timeout_s=_circuit_breaker_reset_seconds())
_REDIS_CIRCUIT = CircuitBreaker(reset_timeout_s=_circuit_breaker_reset_seconds())
_HEALTH_RETRY_BACKOFFS = (0.1, 0.2, 0.4)


# Keep APP_EXECUTOR for backwards compatibility
APP_EXECUTOR = _APP_EXECUTOR


class ChatResponse(BaseModel):
    """Response payload for chat responses."""

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {"answer": ("Context: The latest holdings update was filed on 2024-06-30.")}
            ]
        }
    )
    answer: str = Field(..., description="Generated answer based on stored documents")
    chain_used: str = Field(
        "legacy_search",
        description="Identifier of the chain or handler used to produce the answer",
    )
    sources: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Supporting references used to generate the answer",
    )
    sql: str | None = Field(None, description="Generated SQL, when applicable")
    trace_url: str | None = Field(None, description="Optional trace URL for observability")
    latency_ms: int = Field(0, description="End-to-end request latency in milliseconds")
    response_id: str = Field(..., description="Stable identifier used for feedback submission")
    chat_disabled: bool = Field(
        False,
        description=(
            "True when chat is disabled for the active LLM data zone "
            "(LLM_ZONE=disabled); the UI renders a notice instead of an error"
        ),
    )


class ChatRequest(BaseModel):
    """Request payload for the research assistant chat endpoint."""

    question: str
    chain: str | None = None
    context: dict[str, Any] | None = None


class FeedbackRequest(BaseModel):
    """User feedback captured for a chat response."""

    response_id: str
    rating: int = Field(..., ge=1, le=5)
    comment: str | None = None


class HoldingsAnalysisRequest(BaseModel):
    """Request payload for direct holdings analysis endpoint."""

    question: str = "Analyze current holdings concentration and crowding."
    context: dict[str, Any] | None = None


class HealthDbResponse(BaseModel):
    """Response payload for database health checks."""

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {"healthy": True, "latency_ms": 42},
                {"healthy": False, "latency_ms": 5000},
            ]
        }
    )
    healthy: bool = Field(..., description="Whether the database is reachable")
    latency_ms: int = Field(..., description="Observed database ping latency in milliseconds")


class HealthDetailedResponse(BaseModel):
    """Response payload for detailed health checks."""

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "healthy": True,
                    "uptime_s": 3600,
                    "components": {
                        "app": {"healthy": True, "uptime_s": 3600},
                        "database": {"healthy": True, "latency_ms": 42},
                        "minio": {"healthy": True, "latency_ms": 58},
                        "redis": {"healthy": True, "latency_ms": 12, "enabled": True},
                    },
                }
            ]
        }
    )
    healthy: bool = Field(..., description="Whether all components are healthy")
    uptime_s: int = Field(..., description="Application uptime in seconds")
    components: dict[str, dict[str, int | bool]] = Field(
        ..., description="Per-component health details"
    )


def _format_validation_errors(exc: RequestValidationError) -> list[dict[str, str]]:
    """Normalize validation errors into a concise field/message list."""
    errors: list[dict[str, str]] = []
    for err in exc.errors():
        raw_loc = [str(part) for part in err.get("loc", [])]
        loc = [part for part in raw_loc if part != "body"]
        if loc:
            field = loc[-1]
        elif raw_loc and raw_loc[0] == "body":
            field = "body"
        else:
            field = "unknown"
        errors.append({"field": field, "message": err.get("msg", "Invalid value")})
    return errors


@app.exception_handler(RequestValidationError)
async def _validation_exception_handler(
    _request: Request, exc: RequestValidationError
) -> JSONResponse:
    # Return 400s with field-level messages for API clients.
    errors = _format_validation_errors(exc)
    return JSONResponse(status_code=400, content={"errors": errors, "error": errors})


# OpenAPI metadata keeps /docs clear about chat behavior.
@app.get(
    "/chat",
    response_model=ChatResponse,
    summary="Answer a chat query",
    description=(
        "Search stored documents using the provided question and return a concise "
        "answer composed from the matching context."
    ),
)
def chat(
    q: str = Query(
        ...,
        description="User question",
        examples=cast(
            Any,
            {
                "basic": {
                    "summary": "Holdings question",
                    "value": "What is the latest holdings update?",
                }
            },
        ),
    ),
):
    """Return a naive answer built from stored documents."""
    # Import here to avoid loading embedding models during unrelated endpoints/tests.
    from embeddings import search_documents

    hits = search_documents(q)
    if not hits:
        answer = "No documents found."
    else:
        snippets = []
        for hit in hits:
            kind = hit.get("kind") or "note"
            filename = hit.get("filename") or "unknown"
            manager_name = hit.get("manager_name") or "unassigned"
            snippets.append(f"[{kind} | {filename} | manager: {manager_name}] {hit['content']}")
        answer = "Context: " + " ".join(snippets)
    return {
        "answer": answer,
        "latency_ms": 0,
        "chain_used": "legacy_search",
        "sources": [],
        "sql": None,
        "trace_url": None,
        "response_id": str(uuid.uuid4()),
    }


_SEARCH_ENTITY_TYPE_QUERY = Query(
    None,
    description="Optional result type filter",
)


@app.get(
    "/api/search",
    response_model=list[SearchResult],
    summary="Universal search across managers, filings, holdings, news, and documents",
    description=(
        "Run a unified search query and return ranked results across supported entity types."
    ),
)
async def search_api(
    q: str = Query(
        ...,
        min_length=1,
        description="Search query text",
        examples=cast(
            Any,
            {
                "manager": {
                    "summary": "Manager query",
                    "value": "Elliott",
                }
            },
        ),
    ),
    limit: int = Query(20, ge=1, le=100, description="Maximum number of results to return"),
    entity_type: SearchEntityType | None = _SEARCH_ENTITY_TYPE_QUERY,
) -> list[SearchResult]:
    conn = connect_db()
    try:
        return universal_search(q, conn, limit=limit, entity_type=entity_type)
    finally:
        conn.close()


VALID_CHAIN_NAMES = {
    "auto",
    "filing_summary",
    "holdings_analysis",
    "nl_query",
    "rag_search",
}
DIRECT_CHAIN_PATHS = {
    "filing_summary": ("chains.filing_summary", "FilingSummaryChain"),
    "holdings_analysis": ("chains.holdings_analysis", "HoldingsAnalysisChain"),
    "nl_query": ("chains.nl_query", "NLQueryChain"),
    "rag_search": ("chains.rag_search", "RAGSearchChain"),
}


class ChainUnavailableError(RuntimeError):
    """Raised when a requested chat chain cannot be loaded safely."""


def _chat_chain_fallback_enabled() -> bool:
    """Return True when deterministic chain stubs are explicitly allowed."""
    return load_runtime_config().chat_chain_fallback_mode.strip().lower() in {
        "1",
        "true",
        "yes",
        "dev",
        "offline",
        "stlite",
    }


class InMemoryChatRateLimiter:
    """Simple in-memory session limiter for chat endpoints."""

    def __init__(self, max_requests: int, window_seconds: float) -> None:
        self._max_requests = max_requests
        self._window_seconds = window_seconds
        self._requests: dict[str, deque[float]] = defaultdict(deque)
        self._lock = Lock()

    def check_and_record(self, session_id: str, now: float | None = None) -> bool:
        """Return True when request can proceed and persist request timestamp."""
        current_time = now if now is not None else time.time()
        window_start = current_time - self._window_seconds
        with self._lock:
            history = self._requests[session_id]
            while history and history[0] <= window_start:
                history.popleft()
            if len(history) >= self._max_requests:
                return False
            history.append(current_time)
            return True

    def clear(self) -> None:
        """Reset limiter state; used by tests."""
        with self._lock:
            self._requests.clear()


def _build_chat_rate_limiter() -> InMemoryChatRateLimiter:
    config = load_runtime_config()
    return InMemoryChatRateLimiter(
        max_requests=config.chat_rate_limit_per_minute,
        window_seconds=config.chat_rate_limit_window_seconds,
    )


CHAT_RATE_LIMITER = _build_chat_rate_limiter()
CHAT_IP_RATE_LIMITER = _build_chat_rate_limiter()


def _sign_chat_session_id(session_id: str, secret: str) -> str:
    signature = hmac.new(secret.encode("utf-8"), session_id.encode("utf-8"), hashlib.sha256)
    return f"{session_id}.{signature.hexdigest()}"


def _verified_chat_session_cookie(raw_value: str | None) -> str | None:
    secret = load_runtime_config().chat_session_cookie_secret
    if not raw_value or not secret:
        return None
    try:
        session_id, provided_signature = raw_value.rsplit(".", 1)
    except ValueError:
        return None
    if not session_id or not provided_signature:
        return None
    expected = _sign_chat_session_id(session_id, secret).rsplit(".", 1)[1]
    if not hmac.compare_digest(provided_signature, expected):
        return None
    return session_id


def _chat_session_cookie_name() -> str:
    return load_runtime_config().chat_session_cookie_name


def _chat_session_id(request: Request | None) -> str:
    """Derive a stable quota key without trusting client-chosen headers."""
    if request is None:
        return "unknown"
    client_host = request.client.host if request.client and request.client.host else "unknown"
    session_id = _verified_chat_session_cookie(request.cookies.get(_chat_session_cookie_name()))
    if session_id:
        return f"client:{client_host}:session:{session_id}"
    return f"client:{client_host}"


def _chat_client_id(request: Request | None) -> str:
    if request is None:
        return "client:unknown"
    client_host = request.client.host if request.client and request.client.host else "unknown"
    return f"client:{client_host}"


def _enforce_chat_rate_limit(request: Request | None) -> None:
    """Raise 429 when request count exceeds session budget."""
    client_id = _chat_client_id(request)
    if not CHAT_IP_RATE_LIMITER.check_and_record(client_id):
        raise HTTPException(status_code=429, detail="Rate limit exceeded")
    session_id = _chat_session_id(request)
    if not CHAT_RATE_LIMITER.check_and_record(session_id):
        raise HTTPException(status_code=429, detail="Rate limit exceeded")


class _PromptInjectionError(Exception):
    """Fallback PromptInjectionError when llm.injection is unavailable."""

    def __init__(self, reasons: list[str] | str) -> None:
        if isinstance(reasons, str):
            self.reasons = [reasons]
        else:
            self.reasons = reasons
        super().__init__(", ".join(self.reasons))


def _load_prompt_injection_error_class() -> type[Exception]:
    """Load PromptInjectionError from the expected module when available."""
    try:
        module = importlib.import_module("llm.injection")
        return module.PromptInjectionError
    except (ModuleNotFoundError, AttributeError):
        return _PromptInjectionError


PROMPT_INJECTION_ERROR = _load_prompt_injection_error_class()


def _build_chat_client_info():
    """Build chat client metadata from available provider modules."""
    llm_client_module = None
    try:
        llm_client_module = importlib.import_module("llm.client")
    except ModuleNotFoundError as exc:
        # The chat path must not bypass the local registry-enforcing client.
        if exc.name not in {"llm", "llm.client"}:
            raise
        return None

    if llm_client_module is not None:
        build_fn = getattr(llm_client_module, "build_chat_client", None)
        if callable(build_fn):
            return build_fn()
    return None


# Closed-zone notice surfaced when the LLM boundary is disabled for this deployment.
LLM_ZONE_DISABLED_MESSAGE = (
    "Research chat is disabled in this internal data zone. "
    "Contact an admin to enable an authorized, no-train LLM endpoint."
)


def _chat_zone_disabled() -> bool:
    """Return True when ``LLM_ZONE`` selects the deterministic-only data zone.

    When ``LLM_ZONE=disabled`` the chat boundary is closed: deterministic pages
    keep running on real data inside the org perimeter while the Research path
    returns a structured 200 notice instead of probing a provider or raising
    503. This is the single LLM-boundary switch documented in
    ``docs/deploy/INTERNAL_HOSTING.md``.
    """
    return load_runtime_config().llm_zone.strip().lower() == "disabled"


def _manager_id_column(conn: Any) -> str:
    return manager_id_column(conn, require_table=True) or "id"


def _normalize_manager_ids(value: Any) -> list[int]:
    raw_values = value if isinstance(value, list) else [value]
    manager_ids: list[int] = []
    for raw_value in raw_values:
        try:
            manager_ids.append(int(raw_value))
        except (TypeError, ValueError):
            continue
    return manager_ids


def _normalize_cusips(value: Any) -> list[str]:
    raw_values = value if isinstance(value, list) else [value]
    cusips: list[str] = []
    for raw_value in raw_values:
        text = str(raw_value or "").strip().upper()
        if text:
            cusips.append(text)
    return cusips


def _parse_date_range(value: Any) -> tuple[date, date] | None:
    if isinstance(value, dict):
        start_raw = value.get("start")
        end_raw = value.get("end")
    elif isinstance(value, (list, tuple)) and len(value) == 2:
        start_raw, end_raw = value
    else:
        return None
    if not start_raw or not end_raw:
        return None
    try:
        return (date.fromisoformat(str(start_raw)), date.fromisoformat(str(end_raw)))
    except ValueError:
        return None


def _manager_ids_for_name(conn: Any, manager_name: str) -> list[int]:
    normalized_name = manager_name.strip()
    if not normalized_name:
        return []
    manager_id_col = _manager_id_column(conn)
    placeholder = get_placeholder(conn)
    rows = conn.execute(
        f"SELECT {manager_id_col} FROM managers WHERE lower(name) = lower({placeholder})",
        (normalized_name,),
    ).fetchall()
    manager_ids: list[int] = []
    for row in rows:
        try:
            manager_ids.append(int(row[0]))
        except (TypeError, ValueError, IndexError):
            continue
    return manager_ids


def _normalize_chain_context(context: dict[str, Any] | None, conn: Any) -> dict[str, Any]:
    if not context:
        return {}

    normalized = dict(context)
    manager_ids = _normalize_manager_ids(normalized.get("manager_ids"))
    if not manager_ids:
        manager_ids = _normalize_manager_ids(normalized.get("manager_id"))
    if not manager_ids and isinstance(normalized.get("manager_name"), str):
        manager_ids = _manager_ids_for_name(conn, str(normalized["manager_name"]))
    if manager_ids:
        normalized["manager_ids"] = manager_ids

    cusips = _normalize_cusips(normalized.get("cusips"))
    if cusips:
        normalized["cusips"] = cusips

    parsed_date_range = _parse_date_range(normalized.get("date_range"))
    if parsed_date_range is not None:
        normalized["date_range"] = {
            "start": parsed_date_range[0].isoformat(),
            "end": parsed_date_range[1].isoformat(),
        }
    return normalized


def _context_filter_requested(context: dict[str, Any], *keys: str) -> bool:
    """Return whether a caller supplied a filter beyond an empty optional list."""
    for key in keys:
        value = context.get(key)
        if isinstance(value, (list, tuple)):
            if value:
                return True
        elif value is not None:
            return True
    return False


def _validated_holdings_filters(
    context: dict[str, Any],
) -> tuple[list[int] | None, list[str] | None, tuple[date, date] | None]:
    """Normalize explicit holdings filters without silently widening their scope."""
    manager_ids = _normalize_manager_ids(context.get("manager_ids"))
    if _context_filter_requested(context, "manager_ids", "manager_id", "manager_name"):
        if not manager_ids:
            raise HTTPException(
                status_code=400,
                detail="Manager filter did not resolve to any manager IDs",
            )

    cusips = _normalize_cusips(context.get("cusips"))
    if _context_filter_requested(context, "cusips") and not cusips:
        raise HTTPException(
            status_code=400,
            detail="CUSIP filter must contain at least one non-empty value",
        )

    date_range = _parse_date_range(context.get("date_range"))
    if context.get("date_range") is not None and (
        date_range is None or date_range[0] > date_range[1]
    ):
        raise HTTPException(
            status_code=400,
            detail="Date range must contain valid ISO dates with start on or before end",
        )

    return manager_ids or None, cusips or None, date_range


def _classify_intent(question: str) -> str:
    """Classify user intent or use a deterministic fallback classifier."""
    try:
        module = importlib.import_module("chains.intent")
        classify_intent = module.classify_intent
        chain_name = classify_intent(question)
        if chain_name in DIRECT_CHAIN_PATHS:
            return chain_name
    except (ModuleNotFoundError, AttributeError, TypeError, ValueError):
        logger.debug("Intent classifier unavailable; using deterministic fallback", exc_info=True)

    lowered = question.lower()
    if "sql" in lowered or "query" in lowered or "database" in lowered:
        return "nl_query"
    if "filing" in lowered or "13f" in lowered:
        return "filing_summary"
    if "holding" in lowered or "position" in lowered:
        return "holdings_analysis"
    return "rag_search"


class _FallbackFilingSummaryChain:
    def run(self, filing_id: int) -> dict[str, Any]:
        detail = f" for filing {filing_id}" if filing_id else ""
        return {"answer": f"Filing summary{detail}", "sources": []}


class _FallbackHoldingsAnalysisChain:
    def run(
        self,
        question: str,
        *,
        manager_ids: list[int] | None = None,
        cusips: list[str] | None = None,
        date_range: tuple[date, date] | None = None,
    ) -> dict[str, Any]:
        context: dict[str, Any] = {}
        if manager_ids:
            context["manager_ids"] = manager_ids
        if cusips:
            context["cusips"] = cusips
        if date_range is not None:
            context["date_range"] = [item.isoformat() for item in date_range]
        return {"answer": f"Holdings analysis: {question}", "sources": [context] if context else []}


class _FallbackNLQueryChain:
    def run(self, *, question: str, context: dict[str, Any] | None = None) -> dict[str, Any]:
        sql = "SELECT manager_name, filing_date FROM filings ORDER BY filing_date DESC LIMIT 10;"
        return {"answer": f"Query analysis: {question}", "sql": sql, "sources": context or {}}


class _FallbackRAGSearchChain:
    def run(self, *, question: str, context: dict[str, Any] | None = None) -> dict[str, Any]:
        return {"answer": f"Search results for: {question}", "sources": context or {}}


FALLBACK_CHAINS = {
    "filing_summary": _FallbackFilingSummaryChain,
    "holdings_analysis": _FallbackHoldingsAnalysisChain,
    "nl_query": _FallbackNLQueryChain,
    "rag_search": _FallbackRAGSearchChain,
}


def _build_chain(chain_name: str, client_info: Any):
    """Instantiate a chain by name, falling back to local stubs when missing."""
    module_path, class_name = DIRECT_CHAIN_PATHS[chain_name]
    try:
        module = importlib.import_module(module_path)
        chain_cls = getattr(module, class_name)
    except (ModuleNotFoundError, AttributeError) as exc:
        if _chat_chain_fallback_enabled():
            logger.warning(
                "Using explicit chat chain fallback for %s after load failure",
                chain_name,
                exc_info=True,
            )
            return FALLBACK_CHAINS[chain_name]()
        logger.exception("Chat chain %s is unavailable", chain_name)
        raise ChainUnavailableError(f"Chat chain '{chain_name}' is unavailable") from exc
    except Exception as exc:
        if _chat_chain_fallback_enabled():
            logger.warning(
                "Using explicit chat chain fallback for %s after import error",
                chain_name,
                exc_info=True,
            )
            return FALLBACK_CHAINS[chain_name]()
        logger.exception("Chat chain %s failed during import", chain_name)
        raise ChainUnavailableError(f"Chat chain '{chain_name}' failed during import") from exc

    db_conn = connect_db()
    try:
        if chain_name == "filing_summary":
            return chain_cls(client_info=client_info, db_conn=db_conn)
        if chain_name == "holdings_analysis":
            return chain_cls(client_info=client_info, db_conn=db_conn)
        return chain_cls(llm=client_info.client if client_info else None, db_conn=db_conn)
    except Exception:
        db_conn.close()
        raise


def _normalize_sources(raw_sources: Any) -> list[dict[str, Any]]:
    if isinstance(raw_sources, list):
        normalized: list[dict[str, Any]] = []
        for source in raw_sources:
            if isinstance(source, dict):
                normalized.append(source)
            else:
                normalized.append({"description": str(source)})
        return normalized
    if isinstance(raw_sources, dict):
        return [raw_sources]
    return []


def _extract_chain_payload(result: Any) -> tuple[str, list[dict[str, Any]], str | None, str | None]:
    """Extract answer metadata from dict/object/string chain responses."""
    if isinstance(result, str):
        return result, [], None, None
    if isinstance(result, dict):
        answer = str(result.get("answer") or result.get("response") or "")
        sources = _normalize_sources(result.get("sources"))
        sql = result.get("sql")
        trace_url = result.get("trace_url")
        return answer, sources, sql, trace_url

    answer = str(getattr(result, "answer", "") or getattr(result, "response", ""))
    sources = _normalize_sources(getattr(result, "sources", []))
    sql = getattr(result, "sql", None)
    trace_url = getattr(result, "trace_url", None)
    return answer, sources, sql, trace_url


def _format_filing_summary_payload(result: Any) -> dict[str, Any]:
    payload = result.model_dump() if hasattr(result, "model_dump") else dict(result)
    manager_name = str(payload.get("manager_name") or "Unknown manager")
    filing_date = str(payload.get("filing_date") or "n/a")
    total_positions = payload.get("total_positions")
    total_aum_estimate = payload.get("total_aum_estimate") or "n/a"
    lines = [
        f"{manager_name} filing summary ({filing_date})",
        f"Total positions: {total_positions}",
        f"Estimated AUM: {total_aum_estimate}",
    ]
    key_positions = payload.get("key_positions") or []
    if isinstance(key_positions, list) and key_positions:
        top_names = [
            str(
                position.get("name_of_issuer")
                or position.get("issuer")
                or position.get("cusip")
                or ""
            )
            for position in key_positions[:5]
            if isinstance(position, dict)
        ]
        top_names = [name for name in top_names if name]
        if top_names:
            lines.append("Top positions: " + ", ".join(top_names))
    notable_changes = payload.get("notable_changes") or []
    if isinstance(notable_changes, list) and notable_changes:
        lines.append("Notable changes: " + "; ".join(str(change) for change in notable_changes[:3]))
    risk_flags = payload.get("risk_flags") or []
    if isinstance(risk_flags, list) and risk_flags:
        lines.append("Risk flags: " + "; ".join(str(flag) for flag in risk_flags[:3]))
    return {"answer": "\n".join(lines), "sources": [], "sql": None, "trace_url": None}


def _format_holdings_analysis_payload(result: Any) -> dict[str, Any]:
    payload = result.model_dump() if hasattr(result, "model_dump") else dict(result)
    thesis = str(payload.get("thesis") or "Holdings analysis complete.")
    lines = [thesis]
    top_positions = payload.get("top_positions") or []
    if isinstance(top_positions, list) and top_positions:
        top_names = [
            str(
                position.get("name_of_issuer")
                or position.get("issuer")
                or position.get("cusip")
                or ""
            )
            for position in top_positions[:5]
            if isinstance(position, dict)
        ]
        top_names = [name for name in top_names if name]
        if top_names:
            lines.append("Top positions: " + ", ".join(top_names))
    period_changes = payload.get("period_changes") or []
    if isinstance(period_changes, list) and period_changes:
        lines.append(
            "Period changes: "
            + "; ".join(str(change.get("summary") or change) for change in period_changes[:3])
        )
    concentration_metrics = payload.get("concentration_metrics") or {}
    if isinstance(concentration_metrics, dict) and concentration_metrics:
        lines.append("Concentration metrics: " + json.dumps(concentration_metrics, default=str))
    return {"answer": "\n".join(lines), "sources": [], "sql": None, "trace_url": None}


def _response_id_from_trace_url(trace_url: str | None) -> str | None:
    if trace_url:
        stripped = trace_url.rstrip("/")
        if "/" in stripped:
            candidate = stripped.rsplit("/", 1)[-1]
            if candidate:
                return candidate
    return None


def _ensure_chat_feedback_table(conn: Any) -> None:
    if is_sqlite(conn):
        conn.execute("""CREATE TABLE IF NOT EXISTS chat_feedback (
                feedback_id INTEGER PRIMARY KEY,
                response_id TEXT NOT NULL,
                rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
                comment TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )""")
        return

    if not table_exists(conn, "chat_feedback"):
        raise RuntimeError("chat_feedback table missing; run migrations before accepting feedback")


def _store_feedback(feedback: FeedbackRequest) -> int:
    conn = connect_db()
    try:
        _ensure_chat_feedback_table(conn)
        ph = get_placeholder(conn)
        if is_sqlite(conn):
            cursor = conn.execute(
                f"INSERT INTO chat_feedback(response_id, rating, comment) VALUES ({ph}, {ph}, {ph})",
                (feedback.response_id, feedback.rating, feedback.comment),
            )
            conn.commit()
            return int(cursor.lastrowid or 0)

        row = conn.execute(
            f"INSERT INTO chat_feedback(response_id, rating, comment) VALUES ({ph}, {ph}, {ph}) RETURNING feedback_id",
            (feedback.response_id, feedback.rating, feedback.comment),
        ).fetchone()
        return int(row[0]) if row and row[0] is not None else 0
    finally:
        conn.close()


def _attach_langsmith_feedback(feedback: FeedbackRequest) -> bool:
    if not maybe_enable_langsmith_tracing():
        return False
    try:
        from langsmith import Client as LangSmithClient
    except Exception:
        return False

    try:
        LangSmithClient().create_feedback(
            run_id=feedback.response_id,
            key="user_rating",
            score=feedback.rating,
            comment=feedback.comment,
        )
        return True
    except Exception:
        logger.warning(
            "Failed to attach feedback to LangSmith",
            extra={"response_id": feedback.response_id},
        )
        return False


async def _run_chain(
    chain_name: str, question: str, context: dict[str, Any] | None, client_info: Any
):
    """Execute a chain and return normalized payload."""
    conn = connect_db()
    try:
        normalized_context = _normalize_chain_context(context, conn)
    finally:
        conn.close()

    holdings_manager_ids: list[int] | None = None
    holdings_cusips: list[str] | None = None
    holdings_date_range: tuple[date, date] | None = None
    if chain_name == "holdings_analysis":
        holdings_manager_ids, holdings_cusips, holdings_date_range = _validated_holdings_filters(
            normalized_context
        )

    chain = _build_chain(chain_name, client_info)
    try:
        if chain_name == "filing_summary":
            filing_id = normalized_context.get("filing_id")
            try:
                if filing_id is None:
                    raise TypeError("missing filing_id")
                result = chain.run(int(cast(Any, filing_id)))
            except (TypeError, ValueError) as exc:
                raise HTTPException(
                    status_code=400,
                    detail="filing_summary requires context.filing_id",
                ) from exc
            result = _format_filing_summary_payload(result)
        elif chain_name == "holdings_analysis":
            result = chain.run(
                question,
                manager_ids=holdings_manager_ids,
                cusips=holdings_cusips,
                date_range=holdings_date_range,
            )
            result = _format_holdings_analysis_payload(result)
        elif hasattr(chain, "run"):
            result = chain.run(question=question, context=normalized_context or None)
        elif hasattr(chain, "invoke"):
            result = chain.invoke({"question": question, "context": normalized_context or {}})
        else:
            raise RuntimeError(f"Chain '{chain_name}' does not expose run/invoke")
    finally:
        close = getattr(chain, "db", None)
        try:
            if close is not None and hasattr(close, "close"):
                close.close()
        except Exception:
            pass

    if asyncio.iscoroutine(result):
        result = await result

    return _extract_chain_payload(result)


def _resolve_chain_name(
    requested_chain: str, question: str, context: dict[str, Any] | None = None
) -> str:
    """Resolve requested/auto chain to a concrete chain implementation name."""
    if requested_chain != "auto":
        return requested_chain
    classified_chain = _classify_intent(question)
    if classified_chain == "filing_summary" and not (context or {}).get("filing_id"):
        return "rag_search"
    if classified_chain in DIRECT_CHAIN_PATHS:
        return classified_chain
    return "rag_search"


def _record_chat_fleet_safe(
    *,
    request_id: str,
    endpoint: str,
    chain: str,
    session_id: str | None,
    provider: str | None,
    model: str | None,
    latency_ms: int,
    http_status: int,
    trace_url: str | None = None,
    response_id: str | None = None,
    error_category: str | None = None,
    rate_limited: bool = False,
) -> None:
    """Emit one chat-turn fleet record, swallowing errors so API stays healthy."""
    try:
        run_id = response_id or _response_id_from_trace_url(trace_url) or request_id
        record_chat_event(
            context=ChatFleetContext(
                run_id=run_id,
                request_id=request_id,
                endpoint=endpoint,
                chain=chain,
                session_id=session_id,
                provider=provider,
                model=model,
                trace_url=trace_url,
            ),
            latency_ms=latency_ms,
            http_status=http_status,
            error_category=error_category,
            rate_limited=rate_limited,
            token_usage=TokenUsage(),
            response_id=run_id,
        )
    except Exception:  # pragma: no cover - never let observability break the API
        logger.debug("LangSmith fleet emission failed", exc_info=True)


@app.post("/api/chat", response_model=ChatResponse)
async def chat_api(request: ChatRequest, raw_request: Request) -> ChatResponse:
    """Main chat endpoint with automatic or explicit chain routing."""
    started = time.perf_counter()
    request_id = uuid.uuid4().hex
    endpoint_path = raw_request.url.path if raw_request else "/api/chat"
    session_id = _chat_session_id(raw_request)
    chain_used = "unknown"
    provider_name: str | None = None
    model_name: str | None = None
    try:
        _enforce_chat_rate_limit(raw_request)
        if _chat_zone_disabled():
            latency_ms = int((time.perf_counter() - started) * 1000)
            _record_chat_fleet_safe(
                request_id=request_id,
                endpoint=endpoint_path,
                chain="disabled",
                session_id=session_id,
                provider=None,
                model=None,
                latency_ms=latency_ms,
                http_status=200,
            )
            return ChatResponse(
                answer=LLM_ZONE_DISABLED_MESSAGE,
                chain_used="disabled",
                sources=[],
                sql=None,
                trace_url=None,
                latency_ms=latency_ms,
                response_id=request_id,
                chat_disabled=True,
            )
        client_info = _build_chat_client_info()
        if not client_info:
            raise HTTPException(
                status_code=503,
                detail="No LLM provider configured. Set OPENAI_API_KEY or ANTHROPIC_API_KEY.",
            )
        provider_name = getattr(client_info, "provider", None)
        model_name = getattr(client_info, "model", None)

        requested_chain = (request.chain or "auto").strip().lower()
        if requested_chain not in VALID_CHAIN_NAMES:
            raise HTTPException(status_code=400, detail="Invalid chain")
        chain_used = _resolve_chain_name(requested_chain, request.question, request.context)

        answer, sources, sql, trace_url = await _run_chain(
            chain_used, request.question, request.context, client_info
        )
        latency_ms = int((time.perf_counter() - started) * 1000)
        response_id = _response_id_from_trace_url(trace_url) or str(uuid.uuid4())
        _record_chat_fleet_safe(
            request_id=request_id,
            endpoint=endpoint_path,
            chain=chain_used,
            session_id=session_id,
            provider=provider_name,
            model=model_name,
            latency_ms=latency_ms,
            http_status=200,
            trace_url=trace_url,
            response_id=response_id,
        )
        return ChatResponse(
            answer=answer,
            chain_used=chain_used,
            sources=sources,
            sql=sql,
            trace_url=trace_url,
            latency_ms=latency_ms,
            response_id=response_id,
            chat_disabled=False,
        )
    except PROMPT_INJECTION_ERROR as exc:  # type: ignore[misc]
        reasons = getattr(exc, "reasons", [str(exc)])
        if isinstance(reasons, list):
            reason_text = ", ".join(str(reason) for reason in reasons)
        else:
            reason_text = str(reasons)
        _record_chat_fleet_safe(
            request_id=request_id,
            endpoint=endpoint_path,
            chain=chain_used,
            session_id=session_id,
            provider=provider_name,
            model=model_name,
            latency_ms=int((time.perf_counter() - started) * 1000),
            http_status=400,
            error_category="prompt_injection",
        )
        raise HTTPException(
            status_code=400,
            detail=f"Input rejected: {reason_text}",
        ) from exc
    except ChainUnavailableError as exc:
        logger.error("Chat chain unavailable: %s", exc, exc_info=True)
        _record_chat_fleet_safe(
            request_id=request_id,
            endpoint=endpoint_path,
            chain=chain_used,
            session_id=session_id,
            provider=provider_name,
            model=model_name,
            latency_ms=int((time.perf_counter() - started) * 1000),
            http_status=503,
            error_category="chain_unavailable",
        )
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except HTTPException as exc:
        _record_chat_fleet_safe(
            request_id=request_id,
            endpoint=endpoint_path,
            chain=chain_used,
            session_id=session_id,
            provider=provider_name,
            model=model_name,
            latency_ms=int((time.perf_counter() - started) * 1000),
            http_status=exc.status_code,
            error_category=_error_category_from_http(exc.status_code),
            rate_limited=exc.status_code == 429,
        )
        raise
    except Exception as exc:
        logger.error("Chat error: %s", exc, exc_info=True)
        _record_chat_fleet_safe(
            request_id=request_id,
            endpoint=endpoint_path,
            chain=chain_used,
            session_id=session_id,
            provider=provider_name,
            model=model_name,
            latency_ms=int((time.perf_counter() - started) * 1000),
            http_status=500,
            error_category=type(exc).__name__.lower(),
        )
        raise HTTPException(
            status_code=500,
            detail="Research assistant error. Check server logs.",
        ) from exc


def _error_category_from_http(status_code: int) -> str | None:
    """Map an HTTP status into a coarse fleet error category."""
    if status_code == 429:
        return "rate_limited"
    if status_code == 503:
        return "provider_unavailable"
    if 400 <= status_code < 500:
        return "client_error"
    if status_code >= 500:
        return "server_error"
    return None


@app.post("/api/chat/filing-summary", response_model=ChatResponse)
async def filing_summary(filing_id: int, raw_request: Request) -> ChatResponse:
    """Direct filing summary endpoint."""
    return await chat_api(
        ChatRequest(
            question=f"Summarize filing {filing_id}",
            chain="filing_summary",
            context={"filing_id": filing_id},
        ),
        raw_request,
    )


@app.post("/api/chat/holdings-analysis", response_model=ChatResponse)
async def holdings_analysis(request: HoldingsAnalysisRequest, raw_request: Request) -> ChatResponse:
    """Direct holdings analysis endpoint."""
    return await chat_api(
        ChatRequest(
            question=request.question,
            chain="holdings_analysis",
            context=request.context,
        ),
        raw_request,
    )


@app.post("/api/chat/query", response_model=ChatResponse)
async def nl_query(question: str, raw_request: Request) -> ChatResponse:
    """Direct NL-to-SQL query endpoint."""
    return await chat_api(ChatRequest(question=question, chain="nl_query"), raw_request)


@app.post("/api/chat/search", response_model=ChatResponse)
async def rag_search(question: str, raw_request: Request) -> ChatResponse:
    """Direct RAG search endpoint."""
    return await chat_api(ChatRequest(question=question, chain="rag_search"), raw_request)


@app.post("/api/chat/feedback")
async def submit_feedback(feedback: FeedbackRequest, raw_request: Request) -> dict[str, Any]:
    """Persist user feedback and forward it to LangSmith when available."""
    _enforce_chat_rate_limit(raw_request)
    try:
        feedback_id = _store_feedback(feedback)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    forwarded = _attach_langsmith_feedback(feedback)
    try:
        record_feedback_event(
            response_id=feedback.response_id,
            feedback_id=feedback_id,
            rating=feedback.rating,
            session_id=_chat_session_id(raw_request),
            forwarded_to_langsmith=forwarded,
        )
    except Exception:  # pragma: no cover - never let observability break feedback
        logger.debug("LangSmith fleet feedback emission failed", exc_info=True)
    return {"ok": True, "feedback_id": feedback_id}


def _health_payload() -> dict[str, int | bool]:
    """Build the base app health payload."""
    # Use monotonic time to avoid issues if the system clock changes.
    uptime_s = int(HEALTH_CLOCK.monotonic() - APP_START_TIME)
    return {"healthy": True, "uptime_s": uptime_s}


def _format_dependency_error(exc: Exception) -> str:
    """Return a short reason string for failed dependency checks."""
    message = str(exc).strip()
    return (message or exc.__class__.__name__)[:200]


def _health_summary_timeout_seconds() -> float:
    """Return the /health budget (default 0.2s), bounded to 0.05–0.2s."""
    timeout = _health_timeout_seconds("HEALTH_SUMMARY_TIMEOUT_S", 0.2)
    return max(min(timeout, 0.2), 0.05)


def _chat_chain_health_payload() -> tuple[dict[str, int | bool], str | None]:
    """Report whether production chat chains are importable."""
    fallback_enabled = _chat_chain_fallback_enabled()
    if _chat_zone_disabled():
        return {"healthy": True, "available": True, "fallback_enabled": fallback_enabled}, None
    if fallback_enabled:
        return {"healthy": True, "available": True, "fallback_enabled": True}, None

    for chain_name, (module_path, class_name) in DIRECT_CHAIN_PATHS.items():
        try:
            module = importlib.import_module(module_path)
            getattr(module, class_name)
        except Exception as exc:
            return (
                {"healthy": False, "available": False, "fallback_enabled": False},
                f"{chain_name}: {_format_dependency_error(exc)}",
            )
    return {"healthy": True, "available": True, "fallback_enabled": False}, None


async def _run_dependency_check(
    func,
    timeout_seconds: float,
    *args,
    circuit_breaker: CircuitBreaker | None = None,
    enabled: bool = True,
    include_enabled: bool = False,
) -> tuple[dict[str, int | bool], str | None]:
    """Run a dependency check and return its payload plus failure reason."""
    if not enabled:
        payload = {"healthy": True, "latency_ms": 0}
        if include_enabled:
            payload["enabled"] = False
        return payload, None
    if circuit_breaker and circuit_breaker.is_open():
        payload = {"healthy": False, "latency_ms": 0, "circuit_open": True}
        if include_enabled:
            payload["enabled"] = True
        return payload, "circuit_open"
    start = HEALTH_CLOCK.perf_counter()
    try:
        # Keep retries inside the per-check timeout budget for responsiveness.
        await _run_health_check_with_retries(func, timeout_seconds, *args)
        latency_ms = int((HEALTH_CLOCK.perf_counter() - start) * 1000)
        if circuit_breaker:
            circuit_breaker.record_success()
        payload = {"healthy": True, "latency_ms": latency_ms}
        if include_enabled:
            payload["enabled"] = True
        return payload, None
    except TimeoutError:
        latency_ms = int(min(timeout_seconds, HEALTH_CLOCK.perf_counter() - start) * 1000)
        if circuit_breaker:
            circuit_breaker.record_failure()
        payload = {"healthy": False, "latency_ms": latency_ms}
        if include_enabled:
            payload["enabled"] = True
        return payload, "timeout"
    except Exception as exc:
        latency_ms = int((HEALTH_CLOCK.perf_counter() - start) * 1000)
        if circuit_breaker:
            circuit_breaker.record_failure()
        payload = {"healthy": False, "latency_ms": latency_ms}
        if include_enabled:
            payload["enabled"] = True
        return payload, _format_dependency_error(exc)


async def _run_health_summary_checks(
    timeout_budget: float,
    db_timeout_seconds: float,
    minio_timeout_seconds: float,
    redis_timeout_seconds: float,
    redis_url: str | None,
) -> dict[str, tuple[dict[str, int | bool], str | None]]:
    """Run summary dependency checks with an overall time budget."""
    tasks = {
        "database": asyncio.create_task(
            _run_dependency_check(_ping_db, db_timeout_seconds, db_timeout_seconds)
        ),
        "minio": asyncio.create_task(
            _run_dependency_check(
                _ping_minio,
                minio_timeout_seconds,
                minio_timeout_seconds,
                circuit_breaker=_MINIO_CIRCUIT,
            )
        ),
        "redis": asyncio.create_task(
            _run_dependency_check(
                _ping_redis,
                redis_timeout_seconds,
                redis_url,
                redis_timeout_seconds,
                circuit_breaker=_REDIS_CIRCUIT,
                enabled=bool(redis_url),
                include_enabled=True,
            )
        ),
    }
    task_names = {task: name for name, task in tasks.items()}
    start = HEALTH_CLOCK.perf_counter()
    # Allow a small buffer beyond the budget to avoid false timeouts in the executor.
    overall_timeout = min(timeout_budget + 0.05, 0.2)
    done, pending = await asyncio.wait(tasks.values(), timeout=overall_timeout)
    elapsed_ms = int(min(overall_timeout, HEALTH_CLOCK.perf_counter() - start) * 1000)
    for task in pending:
        task.cancel()
        name = task_names.get(task)
        if name == "minio":
            _MINIO_CIRCUIT.record_failure()
        elif name == "redis" and redis_url:
            _REDIS_CIRCUIT.record_failure()
    if pending:
        await asyncio.gather(*pending, return_exceptions=True)
    results: dict[str, tuple[dict[str, int | bool], str | None]] = {}
    for name, task in tasks.items():
        if task in done:
            results[name] = task.result()
        else:
            payload = {"healthy": False, "latency_ms": elapsed_ms}
            if name == "redis":
                payload["enabled"] = bool(redis_url)
            results[name] = (payload, "timeout")
    return results


@app.get("/health")
async def health_app():
    """Return application health and dependency status."""
    start = HEALTH_CLOCK.perf_counter()
    try:
        app_payload = _health_payload()
        timeout_budget = _health_summary_timeout_seconds()
        db_timeout_seconds = min(_db_timeout_seconds(), timeout_budget)
        minio_timeout_seconds = min(_minio_timeout_seconds(), timeout_budget)
        redis_timeout_seconds = min(_redis_timeout_seconds(), timeout_budget)
        redis_url = os.getenv("REDIS_URL")
        results = await _run_health_summary_checks(
            timeout_budget,
            db_timeout_seconds,
            minio_timeout_seconds,
            redis_timeout_seconds,
            redis_url,
        )
        db_payload, db_reason = results["database"]
        minio_payload, minio_reason = results["minio"]
        redis_payload, redis_reason = results["redis"]
        components = {
            "app": {"healthy": app_payload["healthy"], "uptime_s": app_payload["uptime_s"]},
            "database": db_payload,
            "minio": minio_payload,
            "redis": redis_payload,
        }
        chat_chains_payload, chat_chains_reason = _chat_chain_health_payload()
        components["chat_chains"] = chat_chains_payload
        failed_checks = {}
        if not db_payload["healthy"]:
            failed_checks["database"] = db_reason or "unhealthy"
        if not minio_payload["healthy"]:
            failed_checks["minio"] = minio_reason or "unhealthy"
        if redis_payload.get("enabled", True) and not redis_payload["healthy"]:
            failed_checks["redis"] = redis_reason or "unhealthy"
        if not chat_chains_payload["healthy"]:
            failed_checks["chat_chains"] = chat_chains_reason or "unhealthy"
        redis_healthy = redis_payload["healthy"] if redis_payload.get("enabled", True) else True
        healthy = (
            app_payload["healthy"]
            and db_payload["healthy"]
            and minio_payload["healthy"]
            and redis_healthy
            and chat_chains_payload["healthy"]
        )
        payload = {
            "healthy": healthy,
            "uptime_s": app_payload["uptime_s"],
            "components": components,
            "failed_checks": failed_checks,
        }
        status_code = 200 if healthy else 503
        return JSONResponse(status_code=status_code, content=payload)
    finally:
        # Track summary health latency for dashboards and alerts.
        HEALTH_CHECK_DURATION.labels(endpoint="health").observe(HEALTH_CLOCK.perf_counter() - start)


@app.get("/health/live")
def health_live():
    """Alias liveness endpoint for standard probes."""
    return _health_payload()


@app.get("/healthz")
def healthz():
    """Alias liveness endpoint for common probe conventions."""
    # Keep probe aliases routed through the same liveness payload.
    return _health_payload()


@app.get("/livez")
def health_livez():
    """Alias live probe endpoint for common probe conventions."""
    return _health_payload()


@app.on_event("startup")
async def _configure_default_executor() -> None:
    """Install a known-good default executor for sync endpoints."""
    asyncio.get_running_loop().set_default_executor(_APP_EXECUTOR)
    await start_memory_profiler(app)


def _db_timeout_seconds() -> float:
    """Return the DB health timeout, defaulting to 5s for invalid configuration."""
    # Cap health checks to 5s so monitoring calls never stall longer.
    return min(_health_timeout_seconds("DB_HEALTH_TIMEOUT_S", 5.0), 5.0)


def _ping_db(timeout_seconds: float) -> None:
    """Run a lightweight DB query to verify connectivity."""
    # Pass a connect timeout so the ping doesn't hang on slow networks.
    conn = connect_db(connect_timeout=timeout_seconds)
    try:
        conn.execute("SELECT 1")
    finally:
        conn.close()


def _minio_timeout_seconds() -> float:
    """Return the MinIO timeout (default 5s), capped at 5s."""
    return min(_health_timeout_seconds("MINIO_HEALTH_TIMEOUT_S", 5.0), 5.0)


def _minio_client(timeout_seconds: float):
    """Create a MinIO client with aggressive timeouts for health checks."""
    config = BotoConfig(
        connect_timeout=timeout_seconds,
        read_timeout=timeout_seconds,
        retries={"max_attempts": 0},
    )
    return boto3.client(
        "s3",
        endpoint_url=os.getenv("MINIO_ENDPOINT", "http://localhost:9000"),
        aws_access_key_id=os.getenv("MINIO_ROOT_USER", "minio"),
        aws_secret_access_key=os.getenv("MINIO_ROOT_PASSWORD", "minio123"),
        region_name=os.getenv("MINIO_REGION", "us-east-1"),
        config=config,
    )


def _redis_timeout_seconds() -> float:
    """Return the Redis timeout (default 2s), capped at 5s."""
    return min(_health_timeout_seconds("REDIS_HEALTH_TIMEOUT_S", 2.0), 5.0)


def _ping_redis(redis_url: str, timeout_seconds: float) -> None:
    """Run a lightweight Redis ping to verify cache connectivity."""
    # Import lazily so Redis remains optional outside of cache deployments.
    import redis

    client = redis.Redis.from_url(redis_url, socket_timeout=timeout_seconds)
    client.ping()


def _ping_minio(timeout_seconds: float) -> None:
    """Run a lightweight MinIO API call to verify connectivity."""
    client = _minio_client(timeout_seconds)
    client.list_buckets()


async def _run_health_check_with_retries(
    func,
    timeout_seconds: float,
    *args,
    sleep_fn: Callable[[float], None] | None = None,
    perf_counter_fn: Callable[[], float] | None = None,
) -> None:
    """Run a health check with exponential backoff for flaky dependencies."""

    def _run_with_retries_sync() -> None:
        # Resolve injected timing functions once so retries stay consistent.
        resolved_sleep = sleep_fn or HEALTH_CLOCK.sleep
        resolved_perf_counter = perf_counter_fn or HEALTH_CLOCK.perf_counter
        deadline = resolved_perf_counter() + timeout_seconds
        for backoff in _HEALTH_RETRY_BACKOFFS:
            try:
                func(*args)
                return
            except Exception:
                if resolved_perf_counter() + backoff >= deadline:
                    raise
                resolved_sleep(backoff)
        func(*args)

    await asyncio.wait_for(
        asyncio.get_running_loop().run_in_executor(get_health_executor(), _run_with_retries_sync),
        timeout=timeout_seconds,
    )


@app.get(
    "/health/db",
    response_model=HealthDbResponse,
    summary="Check database connectivity",
    description=(
        "Run a lightweight database ping and return the health status with observed latency."
    ),
    responses={
        503: {
            "model": HealthDbResponse,
            "description": "Database unavailable",
            "content": {
                "application/json": {
                    "examples": {
                        "timeout": {
                            "summary": "Timed out ping",
                            "value": {"healthy": False, "latency_ms": 5000},
                        }
                    }
                }
            },
        }
    },
)
async def health_db():
    """Return database connectivity status and latency."""
    start = HEALTH_CLOCK.perf_counter()
    timeout_seconds = _db_timeout_seconds()
    try:
        # Use a dedicated executor to avoid relying on the loop default executor.
        await _run_health_check_with_retries(_ping_db, timeout_seconds, timeout_seconds)
        latency_ms = int((HEALTH_CLOCK.perf_counter() - start) * 1000)
        payload = {"healthy": True, "latency_ms": latency_ms}
        return JSONResponse(status_code=200, content=payload)
    except TimeoutError:
        # Fail fast to keep the endpoint under the timeout budget.
        latency_ms = int(min(timeout_seconds, HEALTH_CLOCK.perf_counter() - start) * 1000)
        payload = {"healthy": False, "latency_ms": latency_ms}
        return JSONResponse(status_code=503, content=payload)
    except Exception:
        latency_ms = int((HEALTH_CLOCK.perf_counter() - start) * 1000)
        payload = {"healthy": False, "latency_ms": latency_ms}
        return JSONResponse(status_code=503, content=payload)
    finally:
        # Record total DB check duration even when the ping fails.
        HEALTH_CHECK_DURATION.labels(endpoint="health_db").observe(
            HEALTH_CLOCK.perf_counter() - start
        )


@app.get("/health/ready")
async def health_ready():
    """Return readiness status combining app and database checks."""
    start = HEALTH_CLOCK.perf_counter()
    # Reuse the existing health endpoints to keep readiness logic consistent.
    app_payload = _health_payload()
    try:
        db_response = await health_db()
        db_payload = json.loads(db_response.body)
        healthy = app_payload["healthy"] and db_payload["healthy"]
        payload = {
            "healthy": healthy,
            "uptime_s": app_payload["uptime_s"],
            "db_latency_ms": db_payload["latency_ms"],
        }
        status_code = 200 if healthy else 503
        return JSONResponse(status_code=status_code, content=payload)
    finally:
        # Capture readiness latency for alerting dashboards.
        HEALTH_CHECK_DURATION.labels(endpoint="health_ready").observe(
            HEALTH_CLOCK.perf_counter() - start
        )


@app.get("/readyz")
async def health_readyz():
    """Alias readiness endpoint for common probe conventions."""
    # Reuse the main readiness check so probes stay in sync.
    return await health_ready()


@app.get(
    "/health/detailed",
    response_model=HealthDetailedResponse,
    summary="Return detailed health status",
    description="Return per-component health status, including database connectivity.",
    responses={
        503: {
            "model": HealthDetailedResponse,
            "description": "One or more components are unavailable",
        }
    },
)
async def health_detailed():
    """Return detailed health status for app and database components."""
    start = HEALTH_CLOCK.perf_counter()
    # Reuse existing health payloads to keep liveness logic consistent.
    app_payload = _health_payload()
    try:
        db_response = await health_db()
        db_payload = json.loads(db_response.body)
        if _MINIO_CIRCUIT.is_open():
            minio_payload = {"healthy": False, "latency_ms": 0, "circuit_open": True}
        else:
            minio_start = HEALTH_CLOCK.perf_counter()
            minio_timeout_seconds = _minio_timeout_seconds()
            try:
                await _run_health_check_with_retries(
                    _ping_minio, minio_timeout_seconds, minio_timeout_seconds
                )
                minio_latency_ms = int((HEALTH_CLOCK.perf_counter() - minio_start) * 1000)
                _MINIO_CIRCUIT.record_success()
                minio_payload = {"healthy": True, "latency_ms": minio_latency_ms}
            except TimeoutError:
                minio_latency_ms = int(minio_timeout_seconds * 1000)
                _MINIO_CIRCUIT.record_failure()
                minio_payload = {"healthy": False, "latency_ms": minio_latency_ms}
            except Exception:
                minio_latency_ms = int((HEALTH_CLOCK.perf_counter() - minio_start) * 1000)
                _MINIO_CIRCUIT.record_failure()
                minio_payload = {"healthy": False, "latency_ms": minio_latency_ms}
        redis_url = os.getenv("REDIS_URL")
        if redis_url:
            if _REDIS_CIRCUIT.is_open():
                redis_payload = {
                    "healthy": False,
                    "latency_ms": 0,
                    "enabled": True,
                    "circuit_open": True,
                }
            else:
                redis_start = HEALTH_CLOCK.perf_counter()
                redis_timeout_seconds = _redis_timeout_seconds()
                try:
                    await _run_health_check_with_retries(
                        _ping_redis, redis_timeout_seconds, redis_url, redis_timeout_seconds
                    )
                    redis_latency_ms = int((HEALTH_CLOCK.perf_counter() - redis_start) * 1000)
                    _REDIS_CIRCUIT.record_success()
                    redis_payload = {
                        "healthy": True,
                        "latency_ms": redis_latency_ms,
                        "enabled": True,
                    }
                except TimeoutError:
                    redis_latency_ms = int(redis_timeout_seconds * 1000)
                    _REDIS_CIRCUIT.record_failure()
                    redis_payload = {
                        "healthy": False,
                        "latency_ms": redis_latency_ms,
                        "enabled": True,
                    }
                except Exception:
                    redis_latency_ms = int((HEALTH_CLOCK.perf_counter() - redis_start) * 1000)
                    _REDIS_CIRCUIT.record_failure()
                    redis_payload = {
                        "healthy": False,
                        "latency_ms": redis_latency_ms,
                        "enabled": True,
                    }
        else:
            # Skip cache probes when Redis isn't configured in this environment.
            redis_payload = {"healthy": True, "latency_ms": 0, "enabled": False}
        components = {
            "app": {"healthy": app_payload["healthy"], "uptime_s": app_payload["uptime_s"]},
            "database": {
                "healthy": db_payload["healthy"],
                "latency_ms": db_payload["latency_ms"],
            },
            "minio": minio_payload,
            "redis": redis_payload,
        }
        chat_chains_payload, chat_chains_reason = _chat_chain_health_payload()
        if chat_chains_reason:
            chat_chains_payload["reason_present"] = True
        components["chat_chains"] = chat_chains_payload
        redis_healthy = redis_payload["healthy"] if redis_payload["enabled"] else True
        healthy = (
            app_payload["healthy"]
            and db_payload["healthy"]
            and minio_payload["healthy"]
            and redis_healthy
            and chat_chains_payload["healthy"]
        )
        payload = {
            "healthy": healthy,
            "uptime_s": app_payload["uptime_s"],
            "components": components,
        }
        status_code = 200 if healthy else 503
        return JSONResponse(status_code=status_code, content=payload)
    finally:
        # Track full detailed health check latency for dashboards.
        HEALTH_CHECK_DURATION.labels(endpoint="health_detailed").observe(
            HEALTH_CLOCK.perf_counter() - start
        )


@app.get("/metrics")
def metrics() -> Response:
    """Return Prometheus metrics for scraping."""
    # Prometheus expects the text exposition format on this endpoint.
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)


@app.on_event("shutdown")
def _shutdown_executors() -> None:
    """Release the health check executors on app shutdown."""
    _APP_EXECUTOR.shutdown(wait=False, cancel_futures=True)
    _HEALTH_EXECUTOR.shutdown(wait=False, cancel_futures=True)


@app.on_event("shutdown")
async def _shutdown_memory_profiler() -> None:
    """Stop the optional memory profiler task."""
    await stop_memory_profiler(app)


# Commit-message checklist:
# - [ ] type is accurate (feat, fix, test)
# - [ ] scope is clear (health)
# - [ ] summary is concise and imperative
