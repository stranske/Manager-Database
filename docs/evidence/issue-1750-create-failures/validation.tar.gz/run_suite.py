import json,subprocess,time,sys
from pathlib import Path
prefix=Path(sys.argv[1])
argv=["/opt/anaconda3/bin/python3","-m","pytest","tests","-q","--cov",f"--cov-report=json:{prefix}-coverage.json",f"--junitxml={prefix}.xml"]
start=time.time()
with Path(str(prefix)+".stdout").open("w") as out, Path(str(prefix)+".stderr").open("w") as err:
 r=subprocess.run(argv,stdout=out,stderr=err,check=False)
Path(str(prefix)+"-receipt.json").write_text(json.dumps({"argv":argv,"cwd":str(Path.cwd()),"exit":r.returncode,"seconds":time.time()-start,"python_version":subprocess.check_output([argv[0],"--version"],text=True).strip()},indent=2))
print(r.returncode)
